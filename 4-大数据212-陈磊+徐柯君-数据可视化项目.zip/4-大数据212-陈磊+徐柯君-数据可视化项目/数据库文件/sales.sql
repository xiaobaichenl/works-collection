/*
 Navicat Premium Data Transfer

 Source Server         : localhost_3306
 Source Server Type    : MySQL
 Source Server Version : 50739
 Source Host           : localhost:3306
 Source Schema         : car

 Target Server Type    : MySQL
 Target Server Version : 50739
 File Encoding         : 65001

 Date: 30/06/2023 21:19:45
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for sales
-- ----------------------------
DROP TABLE IF EXISTS `sales`;
CREATE TABLE `sales`  (
  `salesid` int(11) NULL DEFAULT NULL,
  `salesname` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `salesdepartment` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `salesteam` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sales
-- ----------------------------
INSERT INTO `sales` VALUES (0, '崔笑仪', '销售部', '1');
INSERT INTO `sales` VALUES (1, '谢无琬', '销售部', '1');
INSERT INTO `sales` VALUES (2, '隗光', '销售部', '1');
INSERT INTO `sales` VALUES (3, '闫黛', '销售部', '1');
INSERT INTO `sales` VALUES (4, '颛孙娟', '销售部', '1');
INSERT INTO `sales` VALUES (5, '齐心', '销售部', '1');
INSERT INTO `sales` VALUES (6, '徐行', '销售部', '1');
INSERT INTO `sales` VALUES (7, '邴被豪', '销售部', '2');
INSERT INTO `sales` VALUES (8, '韦忠富', '销售部', '2');
INSERT INTO `sales` VALUES (9, '昌贝卿', '销售部', '2');
INSERT INTO `sales` VALUES (10, '赵菊', '销售部', '2');
INSERT INTO `sales` VALUES (11, '乐正娣', '销售部', '2');
INSERT INTO `sales` VALUES (12, '红树', '销售部', '2');
INSERT INTO `sales` VALUES (13, '蔡振', '销售部', '3');
INSERT INTO `sales` VALUES (14, '史上航', '销售部', '3');
INSERT INTO `sales` VALUES (15, '詹雄', '销售部', '3');
INSERT INTO `sales` VALUES (16, '成荔', '销售部', '3');
INSERT INTO `sales` VALUES (17, '汤马克', '销售部', '3');
INSERT INTO `sales` VALUES (18, '庞孝朋', '销售部', '3');
INSERT INTO `sales` VALUES (19, '宗忠凡', '财务部', '0');
INSERT INTO `sales` VALUES (20, '父谷电学', '财务部', '0');
INSERT INTO `sales` VALUES (21, '姜庆', '财务部', '0');
INSERT INTO `sales` VALUES (22, '云电凡', '财务部', '0');
INSERT INTO `sales` VALUES (23, '温琦', '财务部', '0');
INSERT INTO `sales` VALUES (24, '詹金霄', '财务部', '0');
INSERT INTO `sales` VALUES (25, '祖良', '财务部', '0');
INSERT INTO `sales` VALUES (26, '任建', '财务部', '0');
INSERT INTO `sales` VALUES (27, '闻电兰', '财务部', '0');
INSERT INTO `sales` VALUES (28, '巫马松', '财务部', '0');
INSERT INTO `sales` VALUES (29, '滕世', '财务部', '0');
INSERT INTO `sales` VALUES (30, '韦礼莲', '财务部', '0');
INSERT INTO `sales` VALUES (31, '云九伦', '技术部', '0');
INSERT INTO `sales` VALUES (32, '席俊', '技术部', '0');
INSERT INTO `sales` VALUES (33, '房昭', '技术部', '0');
INSERT INTO `sales` VALUES (34, '弓礼珠', '技术部', '0');
INSERT INTO `sales` VALUES (35, '姚翠', '技术部', '0');
INSERT INTO `sales` VALUES (36, '鲍无爱', '技术部', '0');
INSERT INTO `sales` VALUES (37, '井歌婕', '技术部', '0');
INSERT INTO `sales` VALUES (38, '路彩', '技术部', '0');
INSERT INTO `sales` VALUES (39, '齐娥', '技术部', '0');

SET FOREIGN_KEY_CHECKS = 1;
