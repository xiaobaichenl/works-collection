#include "login.h"
#include "ui_login.h"

Login::Login(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Login)
{
    ui->setupUi(this);
    this->setWindowTitle("登录界面");
}

Login::~Login()
{
    delete ui;
}

void Login::on_btnLogin_clicked()
{
    strUser = ui->userEdit->text();
    strPass = ui->passEdit->text();
    accept();
}

void Login::paintEvent(QPaintEvent *)//绘画事件
{
    QPalette PAllbackground = this->palette();
    QImage ImgAllbackground(":/img/dl.png");
    QImage fitimgpic=ImgAllbackground.scaled(this->width(),this->height(), Qt::IgnoreAspectRatio);
    PAllbackground.setBrush(QPalette::Window, QBrush(fitimgpic));
    this->setPalette(PAllbackground);
}
