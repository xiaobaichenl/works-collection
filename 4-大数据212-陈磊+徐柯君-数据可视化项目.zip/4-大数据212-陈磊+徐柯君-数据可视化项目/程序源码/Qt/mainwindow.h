#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include<QtCharts>  //引用库
using namespace QtCharts;
#include <QtCore>
#include<QSqlDatabase>
#include <QWebEngineView>

#include<QJsonDocument>
#include<QJsonArray>
#include<QNetworkAccessManager>
#include<QNetworkReply>
#include<QNetworkRequest>
#include<QDebug>
#include <QSqlQuery>
#include<QObject>
#include"cqchartview.h"

QT_CHARTS_USE_NAMESPACE

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE


//数据结构
typedef QPair<QPointF, QString> Data;//点
typedef QList<Data> DataList;//一条线
typedef QList<DataList> DataTable;//多种类型
class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();



    QHBoxLayout *layouts;

    void initCtrl();



    QJsonDocument doc,doc1;
    QNetworkAccessManager *manager;
    QNetworkReply *reply,*reply1,*reply2;
    QJsonArray obj,obj1,obj2;

    bool DBConnect();

    void InitTable();
    void showTable_CX(QSqlQuery curquery);
    int ShowInfo(QSqlQuery curquery);
    QSqlQuery query;

    void KHMYD();
    void KHLX();
    void KHHFlv();

    QPieSeries *pie;
    void updateSliceExploded(QPieSlice *slice);

    void paintEvent(QPaintEvent *);

    void ttt();

    QLabel* label;
    bool labelVisible;
    void leaveEvent(QEvent *event);
    void enterEvent(QEvent *event);
//    void mousePressEvent(QMouseEvent *event);
//    void mouseLeaveEvent(QEvent *);
    QHBoxLayout *layoutR,*layoutC,*layoutL;
    void KHHFlv1();
    void KHLX1();
    void KHMYD1();
    QChartView *chartView1,*chartView3;
    QChart *chart1,*chart2,*chart3;
    QPen pen,pen1;
    QSplineSeries* ser,*ser1;
    QValueAxis*X,*Y;
    CQChartView *chartView2;
    QStackedBarSeries * hBars;
    QBarSet* barSet0,*barSet1;
    QBarCategoryAxis* AxisX;
    QValueAxis* AxisY;


private slots:
    void on_actionDP_triggered();

    void on_actionSQL_triggered();

    void on_btn_CX_clicked();

    void on_btn_CS_clicked();


private:
    Ui::MainWindow *ui;
    QSqlDatabase db;
//    int a[20][3];
};
#endif // MAINWINDOW_H
