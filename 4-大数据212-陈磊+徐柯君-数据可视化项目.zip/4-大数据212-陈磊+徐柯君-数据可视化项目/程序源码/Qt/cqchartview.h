#ifndef CQCHARTVIEW_H
#define CQCHARTVIEW_H

#include <QChartView>
#include <QMouseEvent>
#include <QGraphicsSimpleTextItem>
#include <array>

QT_CHARTS_USE_NAMESPACE

class CQChartView:public QChartView
{
    Q_OBJECT
    using AxisRange = std::array<qreal, 2>;
public:
    explicit CQChartView(QWidget* parent = nullptr);
    CQChartView(QChart *chart, QWidget *parent = nullptr);
    ~CQChartView();
    void saveAxisRange();

protected:
    void mousePressEvent(QMouseEvent *event);
    void mouseMoveEvent(QMouseEvent *event);
    void mouseReleaseEvent(QMouseEvent *event);
    void wheelEvent(QWheelEvent *event);
    void keyPressEvent(QKeyEvent *event);
    void keyReleaseEvent(QKeyEvent *event);

private:
    QPoint prevPoint_;
    bool leftButtonPressed_;
    bool ctrlPressed_;
    bool alreadySaveRange_;
    AxisRange xRange_;
    AxisRange yRange_;
    QGraphicsSimpleTextItem* coordItem_;
};

#endif // CQCHARTVIEW_H
