#include "otherobject.h"
#include <QDebug>
#include"mainwindow.h"

OtherObject::OtherObject(QObject *parent) : QObject(parent)
{

}

void OtherObject::handleData(const QJsonArray& data)
{
    // 在这里处理接收到的数据
    qDebug() << "Received data:" << data;

    KKK(data);
}

void OtherObject::KKK(const QJsonArray& data)
{
    // 在这里进行图形绘制的操作
//    QChartView *chartView1 = new QChartView();
//    QChart *chart1 = new QChart();
//    chart1->setTitle("客户回访率");
//    QPieSeries *pie = new QPieSeries();
//    pie->append(tr("重点客户回访（过）"),1);
//    pie->append("重点客户未回访（过）",2);
//    pie->append("一般客户回访（过）",3);
//    pie->append("一般客户未回访（过）",4);

//    QPieSlice *slice = pie->slices().at(1);
//    slice->setExploded(true);
//    slice->setLabelVisible(true);
//    slice->setPen(QPen(Qt::white,2));

//    chart1->addSeries(pie);
//    chart1->legend()->setVisible(true);
//    chart1->legend()->setAlignment(Qt::AlignBottom);

//    chartView1->setChart(chart1);
//    QHBoxLayout *layout = new QHBoxLayout();
//    layout->addWidget(chartView1);
//    ui->widgetR->setLayout(layout);
////    qDebug() << "Drawing graph with data:" << data;
}
