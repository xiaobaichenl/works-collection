#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QVBoxLayout>
#include <QSqlError>
#include <QHBoxLayout>
#include <QFrame>
#include <QSplitter>
#include <QWidget>


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    initCtrl();
    InitTable();
    //show();

    label = nullptr;
    labelVisible = false;


ui->tableWidgetSQL->setStyleSheet("background-color: transparent;");
ui->tableWidgetQUERY->setStyleSheet("background-color: transparent;");
// 设置表头为透明
QString styleSheet = "QHeaderView::section { background-color: wathet; color: white; }";
ui->tableWidgetQUERY->horizontalHeader()->setStyleSheet(styleSheet);
ui->tableWidgetSQL->horizontalHeader()->setStyleSheet(styleSheet);
// 隐藏垂直滚动条
ui->tableWidgetQUERY->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
//ui->tableWidgetSQL->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
// 隐藏水平滚动条
ui->tableWidgetQUERY->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
ui->tableWidgetSQL->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
// 隐藏垂直表头
ui->tableWidgetQUERY->verticalHeader()->setVisible(false);
ui->tableWidgetSQL->verticalHeader()->setVisible(false);
// 设置表格内字体为白色
QPalette palette = ui->tableWidgetQUERY->palette();
palette.setColor(QPalette::WindowText, Qt::white);
ui->tableWidgetQUERY->setPalette(palette);
palette = ui->tableWidgetSQL->palette();
palette.setColor(QPalette::WindowText, Qt::white);
ui->tableWidgetSQL->setPalette(palette);


    ui->stackedWidget->setCurrentIndex(0);//默认首页

        if(!DBConnect())
            return;//连接数据库

        QString strsql = QString("select id,title,energy,price,car_form,carnum from car");

        query.exec(strsql);
//        query.next();
//        qDebug()<<query.value(5).toString();
        //qDebug()<<query.size();
            ui->tableWidgetSQL->setRowCount(query.size());//table行数
        if(query.size()>0)
            ShowInfo(query);

        //读取fastapi数据
    manager = new QNetworkAccessManager(this);

    reply = manager->get(QNetworkRequest(QUrl("http://127.0.0.1:1223/orderr/ORDERR_DATA")));
    connect(reply, &QNetworkReply::finished, this,&MainWindow::KHMYD);
    reply1 = manager->get(QNetworkRequest(QUrl("http://127.0.0.1:1223/orderr/ORDERR_DATA")));
    connect(reply1, &QNetworkReply::finished, [=](){
            KHHFlv();
            connect(pie, &QPieSeries::hovered, this, &MainWindow::updateSliceExploded);//设置鼠标盘旋在扇形面区域动作

    });
    reply2 = manager->get(QNetworkRequest(QUrl("http://127.0.0.1:1223/car/CAR_DATA")));
    connect(reply2, &QNetworkReply::finished, this,&MainWindow::KHLX);
    //KHLX();
//ttt();

}

void MainWindow::KHMYD(){

        float a[20][3];
    //QStringList *name;
    QByteArray data = reply->readAll();
            //qDebug()<<data;
            QJsonDocument doc = QJsonDocument::fromJson(data);
            // 解析JSON并处理数据
            //qDebug()<<doc;
            if(doc.isArray()){
                //qDebug()<<"shide";
            }
            obj = doc.array(); // 获取 JSON 对象
            //qDebug() << obj;
            for(int i=0;i<20;i++){
                for(int j =0 ; j<3;j++)
                a[i][j]=0;
            }
            for(int i=0;i<obj.count();i++){
                QJsonObject v = obj.at(i).toObject();
                a[v.value("salesid").toInt()][0]++;
                //qDebug()<<(v.value("servescore").toString()).toInt();
                a[v.value("salesid").toInt()][1]+=(v.value("servescore").toString()).toInt();
                a[v.value("salesid").toInt()][2]+=(v.value("cusscore").toString()).toInt();
            }

            for(int i=1;i<19;i++){
            //qDebug()<<"员工ID"<<a[i][0];
            a[i][1]=a[i][1]/a[i][0];//取舍
            a[i][2]=a[i][2]/a[i][0];
//            qDebug()<<"服务满意度"<<a[i][1];
//            qDebug()<<"使用满意度"<<a[i][2];
            }


            chartView3 = new QChartView();
            chart3 = new QChart();
            chart3->setTitle("客户满意度");
            hBars = new QStackedBarSeries ();

            barSet0 = new QBarSet("服务满意度");
            barSet1 = new QBarSet("使用满意度");
            //横坐标
                 AxisX= new QBarCategoryAxis();

                       int num=0;
            for(int i=1;i<19;i++){
                num++;
                *barSet0 <<a[i][1];
                //qDebug()<<a[i][1];
                *barSet1 <<a[i][2];
                AxisX->append("员工"+QString::number(num));
            }

            // 设置背景透明
            chart3->setBackgroundVisible(false);

            hBars->append(barSet0);
            hBars->append(barSet1);

            chart3->addSeries(hBars);
            chart3->setTitle("客户满意度");
            chart3->setAnimationOptions(QChart::SeriesAnimations);

            AxisY = new QValueAxis();
            AxisY->setRange(0,10);
            AxisY->setTickCount(4);
            chart3->addAxis(AxisY,Qt::AlignLeft);
            hBars->attachAxis(AxisY);


                        chart3->addAxis(AxisX,Qt::AlignBottom);


                        connect(barSet0, &QBarSet::hovered, this, [=](bool status, int index){
                            if(status){
                                QString tooltip = QString("员工: %1, 服务满意度: %2").arg(index+1).arg(barSet0->at(index));
                                QToolTip::showText(QCursor::pos(), tooltip);
                            } else {
                                QToolTip::hideText();
                            }
                        });
                        connect(barSet1, &QBarSet::hovered, this, [=](bool status, int index){
                            if(status){
                                QString tooltip = QString("员工: %1, 使用满意度: %2").arg(index+1).arg(barSet1->at(index));
                                QToolTip::showText(QCursor::pos(), tooltip);
                            } else {
                                QToolTip::hideText();
                            }
                        });
            chart3->legend()->setVisible(true);
            chart3->legend()->setAlignment(Qt::AlignBottom);
            chart3->setTheme(QChart::ChartThemeDark);//设置主题1

            chartView3->setChart(chart3);
            layoutL = new QHBoxLayout();
            layoutL->addWidget(chartView3);
            ui->widgetL->setLayout(layoutL);

            reply->deleteLater();

}

void MainWindow::KHMYD1(){
        float a[20][3];
    QByteArray data = reply->readAll();
            QJsonDocument doc = QJsonDocument::fromJson(data);
            if(doc.isArray()){
                //qDebug()<<"shide";
            }
            obj = doc.array(); // 获取 JSON 对象
            for(int i=0;i<20;i++){
                for(int j =0 ; j<3;j++)
                a[i][j]=0;
            }
            for(int i=0;i<obj.count();i++){
                QJsonObject v = obj.at(i).toObject();
                a[v.value("salesid").toInt()][0]++;
                a[v.value("salesid").toInt()][1]+=(v.value("servescore").toString()).toInt();
                a[v.value("salesid").toInt()][2]+=(v.value("cusscore").toString()).toInt();
            }
            for(int i=1;i<19;i++){
            a[i][1]=a[i][1]/a[i][0];//取舍
            a[i][2]=a[i][2]/a[i][0];
            }

            int num=0;
                    //清除原有数据
                    while (barSet0->count() > 0) {
                        barSet0->remove(0);
                    }
                    while (barSet1->count() > 0) {
                        barSet1->remove(0);
                    }
         for(int i=1;i<19;i++){
             num++;
             *barSet0 <<a[i][1];
             *barSet1 <<a[i][2];
         }//qDebug()<<a[1][2];
            // 设置背景透明
            chart3->setBackgroundVisible(false);

            //hBars->clear();
            hBars->append(barSet0);
            hBars->append(barSet1);
            chart3->addSeries(hBars);
            chart3->setAnimationOptions(QChart::SeriesAnimations);


                        connect(barSet0, &QBarSet::hovered, this, [=](bool status, int index){
                            if(status){
                                QString tooltip = QString("员工: %1, 服务满意度: %2").arg(index+1).arg(barSet0->at(index));
                                QToolTip::showText(QCursor::pos(), tooltip);
                            } else {
                                QToolTip::hideText();
                            }
                        });
                        connect(barSet1, &QBarSet::hovered, this, [=](bool status, int index){
                            if(status){
                                QString tooltip = QString("员工: %1, 使用满意度: %2").arg(index+1).arg(barSet1->at(index));
                                QToolTip::showText(QCursor::pos(), tooltip);
                            } else {
                                QToolTip::hideText();
                            }
                        });



            chart3->legend()->setVisible(true);
            chart3->legend()->setAlignment(Qt::AlignBottom);
            chart3->setTheme(QChart::ChartThemeDark);//设置主题1
qDebug()<<chart3<<"wsdqw";

            chartView3->setChart(chart3);qDebug()<<chartView3<<"we2";
            layoutL->addWidget(chartView3);
            ui->widgetL->setLayout(layoutL);

            reply->deleteLater();

}

void MainWindow::KHLX(){
//    QByteArray data = reply2->readAll();
//            //qDebug()<<data;
//            QJsonDocument doc2 = QJsonDocument::fromJson(data);
//            // 解析JSON并处理数据
//            //qDebug()<<doc;
//            if(doc2.isArray()){
//               // qDebug()<<"shide2";
//            }
//            obj2 = doc2.array(); // 获取 JSON 对象
//            //qDebug() << obj;
     float x[2][6];
     for(int i=0;i<2;i++)
         for(int j=0;j<6;j++)
             x[i][j]=0.0;
     int count = 0;
     for(int i=0;i<obj1.count();i++){
         QJsonObject v = obj1.at(i).toObject();
         //qDebug()<<(v.value("servescore").toString()).toInt();
         x[0][(v.value("servescore").toString()).toInt()]++;//服务评分
         x[1][(v.value("cusscore").toString()).toInt()]++;//使用评分
         count++;
         }
     for(int i=0;i<2;i++)
         for(int j=1;j<6;j++)
         {
             x[i][j]=x[i][j]/count;
             qDebug()<<x[i][j];
         }
    chart2 = new QChart();
    chart2->setTitle("评分对比图");



    pen = QPen(QColor("red"));
    pen.setWidth(2);
    pen1 = QPen(QColor("blue"));
//    pen1.setColor(Qt::red);
    pen1.setWidth(2);
    ser = new QSplineSeries();
    ser1 = new QSplineSeries();
    //显示坐标点
    ser->setPointsVisible(true);
    ser->setPointLabelsVisible(true);
//    ser1->setPointsVisible(true);
//    ser1->setPointLabelsVisible(true);


    ser->setPen(pen);
    ser1->setPen(pen1);
        for(int j=1;j<6;j++)
        {
            ser->append(j,x[0][j]);
            ser1->append(j,x[1][j]);
        }
    chart2->addSeries(ser);
    chart2->addSeries(ser1);
    X=new QValueAxis();
    X->setRange(1,5);
    Y=new QValueAxis();
    Y->setRange(0,0.5);
    chart2->addAxis(X,Qt::AlignBottom);
    chart2->addAxis(Y,Qt::AlignLeft);

    // 设置背景透明
    chart2->setBackgroundVisible(false);

    ser->attachAxis(X);
    ser->attachAxis(Y);
    ser1->attachAxis(X);
    ser1->attachAxis(Y);

    chart2->setTheme(QChart::ChartThemeDark);//设置主题1
    chartView2 = new CQChartView(chart2);
    chartView2->setChart(chart2);
    layoutC = new QHBoxLayout();
    layoutC->addWidget(chartView2);
    ui->widgetC->setLayout(layoutC);

    reply2->deleteLater();

}

void MainWindow::KHLX1(){
//    QByteArray data = reply2->readAll();
//            QJsonDocument doc2 = QJsonDocument::fromJson(data);
//            if(doc2.isArray()){
//               // qDebug()<<"shide2";
//            }
//            obj2 = doc2.array(); // 获取 JSON 对象
     float x[2][6];
     for(int i=0;i<2;i++)
         for(int j=0;j<6;j++)
             x[i][j]=0.0;
     int count = 0;
     for(int i=0;i<obj1.count();i++){
         QJsonObject v = obj1.at(i).toObject();
         x[0][(v.value("servescore").toString()).toInt()]++;//服务评分
         x[1][(v.value("cusscore").toString()).toInt()]++;//使用评分
         count++;
         }
     for(int i=0;i<2;i++)
         for(int j=1;j<6;j++)
         {
             x[i][j]=x[i][j]/count;
             qDebug()<<x[i][j];
         }

    ser->clear();
    ser1->clear();

        for(int j=1;j<6;j++)
        {
            ser->append(j,x[0][j]);
            ser1->append(j,x[1][j]);
        }
    chart2->addSeries(ser);
    chart2->addSeries(ser1);
    // 设置背景透明
    chart2->setBackgroundVisible(false);

//qDebug()<<chartView2;
    chart2->setTheme(QChart::ChartThemeDark);//设置主题1
    chartView2->setChart(chart2);
    layoutC->addWidget(chartView2);
    ui->widgetC->setLayout(layoutC);

    reply2->deleteLater();

}


void MainWindow::KHHFlv(){
    QByteArray data1 = reply1->readAll();
            //qDebug()<<data;
            doc1 = QJsonDocument::fromJson(data1);
            // 解析JSON并处理数据
            //qDebug()<<doc1;
            if(doc1.isArray()){
                //qDebug()<<"shide1";
            }
            obj1 = doc1.array(); // 获取 JSON 对象
    int b[2][2];
    for(int i=0;i<2;i++)
        for(int j=0;j<2;j++)
            b[i][j]=0;
    for(int i=0;i<obj1.count();i++){
        QJsonObject v = obj1.at(i).toObject();
        if((v.value("true_price").toString()).toFloat()>=25 && (v.value("cus_kind").toString()).toInt()==1) //重点客户未回访
            b[0][0]++;
        else if((v.value("true_price").toString()).toFloat()<25 && (v.value("cus_kind").toString()).toInt()==1) //一般客户未回访
            b[1][0]++;
        else if((v.value("true_price").toString()).toFloat()>=25 && (v.value("cus_kind").toString()).toInt()==2) //重点客户回访
            b[0][1]++;
        else if((v.value("true_price").toString()).toFloat()<25 && (v.value("cus_kind").toString()).toInt()==2) //一般客户回访
            b[1][1]++;
    }
    for(int i=0;i<2;i++)
        for(int j=0;j<2;j++)
            qDebug()<<b[i][j];
    chartView1 = new QChartView();
    chart1 = new QChart();
    chart1->setTitle("客户回访率");
    pie = new QPieSeries();
    pie->append(tr("重点客户回访（过）"),b[0][1]);
    pie->append("重点客户未回访（过）",b[0][0]);
    pie->append("一般客户回访（过）",b[1][1]);
    pie->append("一般客户未回访（过）",b[1][0]);

    QPieSlice *slice = pie->slices().at(1);
    slice->setExploded(true);
    slice->setLabelVisible(true);
    slice->setPen(QPen(Qt::white,2));

    // 设置背景透明
    chart1->setBackgroundVisible(false);


    chart1->addSeries(pie);
    chart1->legend()->setVisible(true);
    chart1->legend()->setAlignment(Qt::AlignBottom);
    chart1->setAnimationOptions(QChart::SeriesAnimations);

    chart1->setTheme(QChart::ChartThemeDark);//设置主题1

    chartView1->setChart(chart1);
    layoutR = new QHBoxLayout();
    layoutR->addWidget(chartView1);
    ui->widgetR->setLayout(layoutR);

    reply1->deleteLater();

}

void MainWindow::KHHFlv1(){
    QByteArray data1 = reply1->readAll();
            //qDebug()<<data;
            doc1 = QJsonDocument::fromJson(data1);
            // 解析JSON并处理数据
            //qDebug()<<doc1;
            if(doc1.isArray()){
                //qDebug()<<"shide1";
            }
            obj1 = doc1.array(); // 获取 JSON 对象
    int b[2][2];
    for(int i=0;i<2;i++)
        for(int j=0;j<2;j++)
            b[i][j]=0;
    for(int i=0;i<obj1.count();i++){
        QJsonObject v = obj1.at(i).toObject();
        if((v.value("true_price").toString()).toFloat()>=25 && (v.value("cus_kind").toString()).toInt()==1) //重点客户未回访
            b[0][0]++;
        else if((v.value("true_price").toString()).toFloat()<25 && (v.value("cus_kind").toString()).toInt()==1) //一般客户未回访
            b[1][0]++;
        else if((v.value("true_price").toString()).toFloat()>=25 && (v.value("cus_kind").toString()).toInt()==2) //重点客户回访
            b[0][1]++;
        else if((v.value("true_price").toString()).toFloat()<25 && (v.value("cus_kind").toString()).toInt()==2) //一般客户回访
            b[1][1]++;
    }
    for(int i=0;i<2;i++)
        for(int j=0;j<2;j++)
            qDebug()<<b[i][j];
    chart1->setTitle("客户回访率");

    pie->clear();
    pie->append(tr("重点客户回访（过）"),b[0][1]);
    pie->append("重点客户未回访（过）",b[0][0]);
    pie->append("一般客户回访（过）",b[1][1]);
    pie->append("一般客户未回访（过）",b[1][0]);

    QPieSlice *slice = pie->slices().at(1);
    slice->setExploded(true);
    slice->setLabelVisible(true);
    slice->setPen(QPen(Qt::white,2));

    // 设置背景透明
    chart1->setBackgroundVisible(false);


    chart1->addSeries(pie);
    chart1->legend()->setVisible(true);
    chart1->legend()->setAlignment(Qt::AlignBottom);
    chart1->setAnimationOptions(QChart::SeriesAnimations);

    chart1->setTheme(QChart::ChartThemeDark);//设置主题1

    chartView1->setChart(chart1);
    //layoutR = new QHBoxLayout();
    layoutR->addWidget(chartView1);
    ui->widgetR->setLayout(layoutR);

    reply1->deleteLater();

}

void MainWindow::updateSliceExploded(QPieSlice *slice)
{

    // 隐藏所有扇形区域的标签
       foreach (QPieSlice *s, pie->slices()) {
           s->setExploded(false);
           s->setLabelVisible(false);
       }

       // 显示数据值在鼠标位置
           if (slice) {
               // 设置扇形区域为切割状态
               slice->setExploded(true);
               // 将数据值设置为标签文本
               QString dataValue = QString("%1% (%2)").arg(slice->percentage() * 100, 0, 'f', 1).arg(slice->value());
               // 如果标签已存在，则更新其位置和文本；否则创建新的标签
               if (label) {
                   label->setText(dataValue);
                   label->move(QCursor::pos());
               } else {
                   label = new QLabel(nullptr, Qt::ToolTip);
                   label->setText(dataValue);
                   label->setAttribute(Qt::WA_DeleteOnClose);  // 设置在关闭时自动删除
                   label->show();
               }
               slice->setPen(QPen(Qt::white, 2));
               slice->setLabelVisible(true);

           }
           else {
               // 鼠标离开扇形区域时隐藏数据值标签
//               if (labelVisible) {
//                   if (label || label->toolTip().contains("%")) {
//                       label->close();  // 调用close方法来隐藏并删除标签
//                       delete label;    // 手动删除标签对象，以便下次重新创建

//                   }
                   label->close();  // 调用close方法来隐藏并删除标签
                   delete label;
                   label = nullptr;
                   labelVisible = false;
//               }

           }

}



void MainWindow::enterEvent(QEvent *event)
{
//    if (!label) {
//        label = new QLabel(ui->widgetC);
//        // 设置标签的文本、位置等属性
//        label->setText("这是一个标签");
//        label->setGeometry(10, 10, 100, 30);
//        label->show();  // 显示标签
//    }
    QWidget::enterEvent(event);
}

void MainWindow::leaveEvent(QEvent *event)
{
//    if (label) {
//        label->close();  // 调用close方法来隐藏并删除标签
//        label = nullptr;
//    }
    QMainWindow::leaveEvent(event);
}

MainWindow::~MainWindow()
{
    delete ui;
}

bool MainWindow::DBConnect(){
    bool blResult = false; //结果
        db = QSqlDatabase::addDatabase("QMYSQL");
        db.setHostName("127.0.0.1");
        db.setPort(3306);
        db.setUserName("root");
        db.setPassword("Cl20031121");
        db.setDatabaseName("car");
    if(!db.open()){
        blResult = false;
        QMessageBox::critical(this,"错误",db.lastError().text());}
    else{blResult = true;//QMessageBox::information(this,"cg","ss");
    }
    query = QSqlQuery(db);
    return blResult;
}

void MainWindow::InitTable(){
    QString strsql = QString("select id,title,energy,price,car_form,carnum from car");

    // 将调整模式设置为Stretch，使列随着窗口大小变化而自动拉伸
    QHeaderView *header = ui->tableWidgetSQL->horizontalHeader();
    header->setSectionResizeMode(QHeaderView::Stretch);
    QHeaderView *header1 = ui->tableWidgetQUERY->horizontalHeader();
    header1->setSectionResizeMode(QHeaderView::Stretch);
}

int MainWindow::ShowInfo(QSqlQuery curquery){
    int i=0,j=ui->tableWidgetSQL->columnCount();
    while(curquery.next()){
        for(j=0;j<ui->tableWidgetSQL->columnCount();j++){
            ui->tableWidgetSQL->setItem(i,j,new QTableWidgetItem(curquery.value(j).toString()));
            //qDebug()<<curquery.value(j).toString();
        }
        i++;
    }
    return curquery.size();
}

void MainWindow::showTable_CX(QSqlQuery curquery)
{
    int i=0,j=ui->tableWidgetQUERY->columnCount();
    while(curquery.next()){
        for(j=0;j<ui->tableWidgetQUERY->columnCount();j++){
            ui->tableWidgetQUERY->setRowCount(10);
            ui->tableWidgetQUERY->setItem(i,j,new QTableWidgetItem(curquery.value(j).toString()));
            //qDebug()<<curquery.value(j).toString();
        }
        i++;
    }
}


void MainWindow::initCtrl()
{

    QSplitter* splitter = new QSplitter(ui->frame);

    QWebEngineView* webView = new QWebEngineView();
    //qDebug()<<webView;
//连接h5大屏
    QUrl url("http://localhost:63342/%E8%87%AA%E5%B7%B1%E7%88%AC_%E5%89%AF%E6%9C%AC4/20/index.html?_ijt=3l4kjl7gogbicjf7aao1gbdurf&_ij_reload=RELOAD_ON_SAVE");
    webView->load(url);

    splitter->addWidget(webView);
    ui->frame->layout()->addWidget(splitter);
    ui->frame->raise();
}


void MainWindow::on_actionDP_triggered()
{
    ui->stackedWidget->setCurrentIndex(0);
}

void MainWindow::on_actionSQL_triggered()
{
    ui->stackedWidget->setCurrentIndex(1);
}

void MainWindow::on_btn_CX_clicked()
{
    QString data = ui->lineEdit_CX->text();
    if(db.open())
    {
        QSqlQuery query(db);
        if(query.exec(QString("select id,title,energy,price,car_form,carnum from car where title like '%%1%';").arg(data)))
        {
            //QMessageBox::information(this,"提示","查找成功");
            showTable_CX(query);
        }
    }
}

void MainWindow::on_btn_CS_clicked()
{
  if(db.open())
     {
         QString name=ui->lineEditCS->text();//输入


         QSqlQuery query(db);
         QString tableName = "car";
         //更新数据库数据
         QString sql=QString("UPDATE %1 SET carnum = carnum - 1 WHERE title  LIKE '%2';").arg(tableName).arg(name);
         if(query.exec(sql))
             {
                  QMessageBox::information(this,"提示","恭喜您成为尊贵的 ~"+name+"~车主！");
              //更新table数据
                  QSqlQuery query1(db);
                  query1.exec(QString("select id,title,energy,price,car_form,carnum from car;"));
                  ShowInfo(query1);
                  //添加订单
                  query1.exec(QString("SELECT * FROM orderr ORDER BY id DESC LIMIT 1;"));
                  query1.next();
                  //qDebug()<<query1.value(0).toInt();
                  int orderID = query1.value(0).toInt()+2;//订单id
                  QString ID = QString::number(query1.value(1).toInt() + 2);
                  QString Name = ui->lineEditCS->text();

                  QString Customer = ui->lineEditKH->text();
                  int Salesid = ui->lineEditXS->text().toInt();
                  QString servescore = QString::number(4);
                  QString cusscore = QString::number(4);
                  QDateTime currentDateTime = QDateTime::currentDateTime();
                  QString saledata = currentDateTime.toString("yyyy-MM-dd");

                  QString cus_kind = QString::number(1);
                  QString saleform = QString("实体店");
                  QString salepro = QString("上海");

                  query1.exec(QString("select price from car where title ='%1';").arg(Name));
                  query1.next();
                  QString true_price = query1.value(0).toString();
                  qDebug()<<orderID<<ID<<Name<<Customer<<Salesid<<servescore<<cusscore<<saledata<<true_price<<cus_kind<<saleform<<salepro;

                  query1.exec(QString("insert into orderr values(%1,'%2','%3','%4',%5,'%6','%7','%8','%9','%10','%11','%12');").arg(orderID).arg(ID).arg(Name).arg(Customer).arg(Salesid).arg(servescore).arg(cusscore).arg(saledata).arg(true_price).arg(cus_kind).arg(saleform).arg(salepro));

                  //query1.exec(QString());
             }
             else
             {
                  QMessageBox::information(this,"提示",tr("%1").arg(query.lastError().text()));
             }
         }
  reply = manager->get(QNetworkRequest(QUrl("http://127.0.0.1:1223/orderr/ORDERR_DATA")));
  connect(reply, &QNetworkReply::finished, this,&MainWindow::KHMYD1);
//  QLayout *oldLayout = ui->widgetR->layout();
//  delete oldLayout;

  reply1 = manager->get(QNetworkRequest(QUrl("http://127.0.0.1:1223/orderr/ORDERR_DATA")));
  connect(reply1, &QNetworkReply::finished, [=](){
          KHHFlv1();
          connect(pie, &QPieSeries::hovered, this, &MainWindow::updateSliceExploded);//设置鼠标盘旋在扇形面区域动作
  });
  reply2 = manager->get(QNetworkRequest(QUrl("http://127.0.0.1:1223/car/CAR_DATA")));
  connect(reply2, &QNetworkReply::finished, this,&MainWindow::KHLX1);
}

void MainWindow::paintEvent(QPaintEvent *)//绘画事件
{
    QPalette PAllbackground = this->palette();
    QImage ImgAllbackground(":/img/interact.png");
    QImage fitimgpic=ImgAllbackground.scaled(this->width(),this->height(), Qt::IgnoreAspectRatio);
    PAllbackground.setBrush(QPalette::Window, QBrush(fitimgpic));
    this->setPalette(PAllbackground);
}

