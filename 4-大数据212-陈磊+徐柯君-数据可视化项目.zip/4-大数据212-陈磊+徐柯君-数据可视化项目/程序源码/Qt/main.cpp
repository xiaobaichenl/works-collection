#include "mainwindow.h"
#include"login.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow m;
//    Login w;
//        int count=0;
//        while(w.exec() == QDialog::Accepted){
//            if(count>=2 && (w.strPass != "123" || w.strUser != "cl"))
//            {
//                QMessageBox::question(&w,"提示","用户名或密码错误三次");
//                break;
//            }
//            if(w.strPass != "123" || w.strUser != "cl"){

//                    w.strUser.clear();
//                    w.strPass.clear();
//                    QMessageBox::warning(&w,"登录失败","用户名或密码错误,(错误三次锁定)");
//                  w.show();//重新弹出登录框
//                  count++;
//            }

//            if(w.strPass == "123" && w.strUser == "cl")
//            {
//                 m.setWindowTitle("汽车公司运营");
//                  m.setWindowIcon(QIcon(":/img/dlu.png"));
//                  m.showMaximized();//最大化显示
//                break;
//            }
//        }
//    QDesktopWidget *desktop = QApplication::desktop();
//    w.move((desktop->width() - w.width())/ 2, (desktop->height() - w.height()) /2);
    m.setWindowTitle("汽车公司运营");
    m.setWindowIcon(QIcon(":/img/dlu.png"));
    m.showMaximized();//最大化显示
    return a.exec();
}
