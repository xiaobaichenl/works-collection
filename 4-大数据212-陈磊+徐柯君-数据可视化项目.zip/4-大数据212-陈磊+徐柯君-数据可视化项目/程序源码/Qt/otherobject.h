#ifndef OTHEROBJECT_H
#define OTHEROBJECT_H

#include <QObject>
#include <QJsonArray>

class OtherObject: public QObject
{
    Q_OBJECT
public:
    explicit OtherObject(QObject *parent = nullptr);

public slots:
    void handleData(const QJsonArray& data);
    void KKK(const QJsonArray& data);
};

#endif // OTHEROBJECT_H
