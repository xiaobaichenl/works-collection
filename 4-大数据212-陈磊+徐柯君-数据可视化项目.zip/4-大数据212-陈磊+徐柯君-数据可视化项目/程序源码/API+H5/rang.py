import os.path
import time
import requests
import csv
import pymysql
import random
import radar
import pymysql
data1=[]
data2=[]
data3=[]
datasa=[]
salepart = []
xuanchuanpart = []
caiwupart = []
tecpart = []
datacar = []
dataorder = []
id = 1000
orderid = 0               

def sale(i):
    salesdepartment=""
    # salesid = random.randint(1,40)
    salesname = random_name()
    salesteam = 0
    if(i<=18):
        salesdepartment="销售部"
        if(i<=6):
            salesteam=1
        if(i<=12 and i>6):
            salesteam=2
        if(i<=18 and i>12):
            salesteam=3
    if(i>18 and i<=30):
        salesdepartment="财务部"
        salesteam=0
    if(i>30 and i<=40):
        salesdepartment="技术部"
        salesteam=0
    return i,salesname,salesdepartment,salesteam

def random_name():
    # 删减部分小众姓氏
    firstName = "赵钱孙李周吴郑王冯陈褚卫蒋沈韩杨朱秦尤许何吕施张孔曹严华金魏陶姜戚谢邹喻水云苏潘葛奚范彭郎鲁韦昌马苗凤花方俞任袁柳鲍史唐费岑薛雷贺倪汤滕殷罗毕郝邬安常乐于时傅卞齐康伍余元卜顾孟平" \
                "黄和穆萧尹姚邵湛汪祁毛禹狄米贝明臧计成戴宋茅庞熊纪舒屈项祝董粱杜阮席季麻强贾路娄危江童颜郭梅盛林刁钟徐邱骆高夏蔡田胡凌霍万柯卢莫房缪干解应宗丁宣邓郁单杭洪包诸左石崔吉" \
                "龚程邢滑裴陆荣翁荀羊甄家封芮储靳邴松井富乌焦巴弓牧隗山谷车侯伊宁仇祖武符刘景詹束龙叶幸司韶黎乔苍双闻莘劳逄姬冉宰桂牛寿通边燕冀尚农温庄晏瞿茹习鱼容向古戈终居衡步都耿满弘国文东殴沃曾关红游盖益桓公晋楚闫"
    # 百家姓姓氏
    # firstName = "赵钱孙李周吴郑王冯陈褚卫蒋沈韩杨朱秦尤许何吕施张孔曹严华金魏陶姜戚谢邹喻柏水窦章云苏潘葛奚范彭郎鲁韦昌马苗凤花方俞任袁柳酆鲍史唐费廉岑薛雷贺倪汤滕殷罗毕郝邬安常乐于时傅皮卞齐康伍余元卜顾孟平" \
    #             "黄和穆萧尹姚邵湛汪祁毛禹狄米贝明臧计伏成戴谈宋茅庞熊纪舒屈项祝董粱杜阮蓝闵席季麻强贾路娄危江童颜郭梅盛林刁钟徐邱骆高夏蔡田樊胡凌霍虞万支柯昝管卢莫经房裘缪干解应宗丁宣贲邓郁单杭洪包诸左石崔吉钮" \
    #             "龚程嵇邢滑裴陆荣翁荀羊於惠甄麴家封芮羿储靳汲邴糜松井段富巫乌焦巴弓牧隗山谷车侯宓蓬全郗班仰秋仲伊宫宁仇栾暴甘钭厉戎祖武符刘景詹束龙叶幸司韶郜黎蓟薄印宿白怀蒲邰从鄂索咸籍赖卓蔺屠蒙池乔阴欎胥能苍" \
    #             "双闻莘党翟谭贡劳逄姬申扶堵冉宰郦雍舄璩桑桂濮牛寿通边扈燕冀郏浦尚农温别庄晏柴瞿阎充慕连茹习宦艾鱼容向古易慎戈廖庾终暨居衡步都耿满弘匡国文寇广禄阙东殴殳沃利蔚越夔隆师巩厍聂晁勾敖融冷訾辛阚那简饶空" \
    #             "曾毋沙乜养鞠须丰巢关蒯相查後荆红游竺权逯盖益桓公晋楚闫法汝鄢涂钦归海帅缑亢况后有琴梁丘左丘商牟佘佴伯赏南宫墨哈谯笪年爱阳佟言福百家姓终"
    # 百家姓中双姓氏
    firstName2="万俟司马上官欧阳夏侯诸葛闻人东方赫连皇甫尉迟公羊澹台公冶宗政濮阳淳于单于太叔申屠公孙仲孙轩辕令狐钟离宇文长孙慕容鲜于闾丘司徒司空亓官司寇仉督子颛孙端木巫马公西漆雕乐正壤驷公良拓跋夹谷宰父谷梁段干百里东郭南门呼延羊舌微生梁丘左丘东门西门南宫南宫"
    # 女孩名字
    girl = '秀娟英华慧巧美娜静淑惠珠翠雅芝玉萍红娥玲芬芳燕彩春菊兰凤洁梅琳素云莲真环雪荣爱妹霞香月莺媛艳瑞凡佳嘉琼勤珍贞莉桂娣叶璧璐娅琦晶妍茜秋珊莎锦黛青倩婷姣婉娴瑾颖露瑶怡婵雁蓓纨仪荷丹蓉眉君琴蕊薇菁梦岚苑婕馨瑗琰韵融园艺咏卿聪澜纯毓悦昭冰爽琬茗羽希宁欣飘育滢馥筠柔竹霭凝晓欢霄枫芸菲寒伊亚宜可姬舒影荔枝思丽'
    # 男孩名字
    boy = '伟刚勇毅俊峰强军平保东文辉力明永健世广志义兴良海山仁波宁贵福生龙元全国胜学祥才发武新利清飞彬富顺信子杰涛昌成康星光天达安岩中茂进林有坚和彪博诚先敬震振壮会思群豪心邦承乐绍功松善厚庆磊民友裕河哲江超浩亮政谦亨奇固之轮翰朗伯宏言若鸣朋斌梁栋维启克伦翔旭鹏泽晨辰士以建家致树炎德行时泰盛雄琛钧冠策腾楠榕风航弘'
    # 名
    name = '中笑贝凯歌易仁器义礼智信友上都卡被好无九加电金马钰玉忠孝'
 
    # 10%的机遇生成双数姓氏
    if random.choice(range(100))>10:
        firstName_name =firstName[random.choice(range(len(firstName)))]
    else:
        i = random.choice(range(len(firstName2)))
        firstName_name =firstName2[i:i+2]
 
    sex = random.choice(range(2))
    name_1 = ""
    # 生成并返回一个名字
    if sex > 0:
        girl_name = girl[random.choice(range(len(girl)))]
        if random.choice(range(2)) > 0:
            name_1 = name[random.choice(range(len(name)))]
        return firstName_name + name_1 + girl_name
    else:
        boy_name = boy[random.choice(range(len(boy)))]
        if random.choice(range(2)) > 0:
            name_1 = name[random.choice(range(len(name)))]
        return firstName_name + name_1 + boy_name
 
def get_basic_data(id):
    url=f'https://mapi.guazi.com/car-source/carRecord/pcConfigurations?clueId={id}'

    res=requests.get(url)
    data=res.json()['data']['list'][0]['children']
    posts={}
    for line in data:
        posts[line['title']]=line['content']

    energy=posts['能源形式']
    price=posts['厂商指导价(万元)']
    try:
        time_market=posts['上市时间']
    except:
        time_market =''
    try:
        motor=posts['发动机']
    except:
        motor=''
    try:
        gearbox=posts['变速箱']
    except:
        gearbox=''
    try:
        gas_mileage=posts['工信部综合油耗(L/100km)']
    except:
        try:
            gas_mileage = posts['工信部纯电续航里程(km)']
        except:
            gas_mileage=''
    car_form=posts['车身形式']
    return energy,price,time_market,motor,gearbox,gas_mileage,car_form



class ConnMysql():
    def __init__(self):
        try:
            self.con = pymysql.connect(host="localhost", user="root", password="Cl20031121", database="car")
        except Exception as error:
            print(error)
        else:
            print("连接成功")

    def clearcar(self):
        sql = 'truncate table car'
        cur = self.con.cursor()
        cur.execute(sql)
    def clearorder(self):
        sql = 'truncate table orderr'
        cur = self.con.cursor()
        cur.execute(sql)
    def clearsales(self):
        sql = 'truncate table sales'
        cur = self.con.cursor()
        cur.execute(sql)
    def insertcar(self,datalist):
        sql = 'insert into car values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)'
        cur=self.con.cursor()
        try:
            cur.execute(sql, datalist)
            self.con.commit()
        except Exception as error:
            print(error)
            self.con.rollback()
        else:
            print("car插入成功")

    def insertordrt(self,datalist):
        sql2 = 'insert into orderr values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)'
        cur=self.con.cursor()
        try:
            cur.execute(sql2, datalist)
            self.con.commit()
        except Exception as error:
            print(error)
            self.con.rollback()
        else:
            print("orderr插入成功")

    def insertsalest(self,datalist):
        sql3 = 'insert into sales(salesid,salesname,salesdepartment,salesteam) values(%s,%s,%s,%s)'
        cur = self.con.cursor()
        try:
            cur.executemany(sql3, datalist)
            self.con.commit()
        except Exception as error:
            print(error)
            self.con.rollback()
        else:
            print("sales插入成功")  

    def spider(self):
        id = 1000
        orderid = 0
        numcar = 0
        for page in range(1,25):
            print(f'第{page}页')
            url="https://mapi.guazi.com/car-source/carList/pcList?" \
                "&tag=-1" \
                "&priceRange=0,-1" \
                f"&page={page}" \
                "&pageSize=20" \
                "&city_filter=13" \
                "&city=13" \
                "&guazi_city=13"

            res=requests.get(url)
            
            posts=res.json()['data']['postList']
            for post in posts:
                id += 1
                orderid +=1
                customer =  random_name()
                servescore = random.randint(1, 5)
                cusscore = random.randint(1, 5)
                salesid = random.randint(1, 18)
                numcar = random.randint(5, 20)
                saledata = radar.random_date("2023-01-01","2023-06-20")
                saledata = str(radar.random_date("2023-01-01","2023-06-20"))
                pro = ['北京','上海','河北','云南','江苏','天津','天津','浙江']
                form = ['网站','小程序','实体店'] 
                salepro = ""
                saleform = ""
                salepro = random.choice(pro)
                saleform = random.choice(form)
                date = saledata.split(" ")
                date = date[0]
                title=post['title']
                cid=post['clue_id']
                energy,price,time_market,motor,gearbox,gas_mileage,car_form=get_basic_data(cid)
                true_price = price
                
                # # 数据库操作
                # # (1)定义一个格式化的sql语句
                # sql = 'insert into car(id,title,energy,price,time_market,motor,gearbox,gas_mileage,car_form) values(%s,%s,%s,%s,%s,%s,%s,%s,%s)'
                data = [id,title,energy,price,time_market,motor,gearbox,gas_mileage,car_form,numcar]
                # datacar.append(data)
                # sql2 = 'insert into orderr values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)'
                # # # (2)准备数据
                if id%2==0:
                    data2 = [orderid,id,title,customer,salesid,servescore,cusscore,date,true_price,random.randint(1, 2),saleform,salepro]
                    # self.insertordrt(data2)
                    save_order(data2)
                # dataorder.append(data2)
                
                save_car(data)
                # self.insertcar(data)
               
                time.sleep(1)
        # print(datacar)
        # self.insertcar(datacar)
        # self.insertordrt(dataorder)
    
    def sales(self):
        for i in range(40):
            salesid,salesname,salesdepartment,salesteam=sale(i)
            data3 = [salesid,salesname,salesdepartment,salesteam]
            datasa.append(data3)
        save_sale(datasa)
        # self.insertsalest(datasa)

def save_car(car):
    _mysql=ConnMysql()
    _mysql.insertcar(car)

def save_order(orddr):
    _mysql=ConnMysql()
    _mysql.insertordrt(orddr)

def save_sale(sale):
    _mysql=ConnMysql()
    _mysql.insertsalest(sale)


# con = pymysql.connect(
#         host = 'localhost',
#         user = 'root',
#         password = '123',
#         database = 'car',
#         port = 3306
#         )
# cursor=con.cursor()
# sql = 'truncate table car'
# cursor.execute(sql)
# sql = 'truncate table orderr'
# cursor.execute(sql)
# sql = 'truncate table sales'
# cursor.execute(sql)
# con.commit()


        # cursor=con.cursor()
        # # # # (3)操作
        # try:
        # cursor.execute(sql,data)
        # cursor.execute(sql2,data2)
        # con.commit()
        # except Exception as e:
        #     print('1插入数据失败',e)
        #     con.rollback() #回滚



           # # (2)准备数据
        # for i in range (40):
        #     data3 = (salesid,salesname,salesdepartment,salesteam)
        # cursor=con.cursor()
        # # # # (3)操作
        # try:
        #     # cursor.execute(sql,data)
        #     cursor.execute(sql2,data2)
        #     con.commit()
        # except Exception as e:
        #     print('3插入数据失败',e)
        #     con.rollback() #回滚


# sql3 = 'insert into sales(salesid,salesname,salesdepartment,salesteam) values(%s,%s,%s,%s)'
# for i in range (40):
#     salesid,salesname,salesdepartment,salesteam=sale()
#     data3 = (salesid,salesname,salesdepartment,salesteam)
#     cursor=con.cursor()
#     try:
#         cursor.execute(sql3,data3)
#         con.commit()
#     except Exception as e:
#         print('2插入数据失败',e)
#         con.rollback() #回滚
#     finally:
#         cursor.close()  # 关闭游标对象
#         con.close()
                   
        
        # # 关闭游标
        # cursor.close()
        # # 关闭连接
        # conn.close()

        # with open(file_name1,'a',encoding='utf-8-sig',newline='') as f:
        #     csv_writer=csv.writer(f)
        #     if flag:
        #         csv_writer.writerow(['id','标题','能源形式','厂商指导价','上市时间','发动机','变速箱','油耗','车身形式'])
        #         flag=False
            
        #     csv_writer.writerow([id,title,energy,price,time_market,motor,gearbox,gas_mileage,car_form])
        # with open(file_name2,'a',encoding='utf-8-sig',newline='') as f:
        #     csv_writer=csv.writer(f)
        #     if flag:
        #         csv_writer.writerow(['id','标题','能源形式','厂商指导价','上市时间','发动机','变速箱','油耗','车身形式'])
        #         flag=False
            
            # csv_writer.writerow([id,title,energy,price,time_market,motor,gearbox,gas_mileage,car_form])
        # print('\t',id,title,energy,price,time_market,motor,gearbox,gas_mileage,car_form)




