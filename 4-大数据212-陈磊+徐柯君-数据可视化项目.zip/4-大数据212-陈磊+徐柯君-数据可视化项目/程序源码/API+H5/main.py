from rang import *
import threading
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from car_data import my_car_data
from sales_data import my_sales_data
from orderr_data import my_orderr_data
import uvicorn
myapp = FastAPI()
myapp.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"]
)


@myapp.get(
    path='/',
    tags=['主页']
)
def welcome():
    return {
        'message': 'Welcome!'
    }

#加载子路由
myapp.include_router(
    router=my_car_data,
    prefix='/car',
    tags=['汽车子路由']
)
myapp.include_router(
    router=my_sales_data,
    prefix='/sales',
    tags=['员工子路由']
)

myapp.include_router(
    router=my_orderr_data,
    prefix='/orderr',
    tags=['订单子路由']
)



if __name__=='__main__':
    mysql=ConnMysql()
    # 每一次执行前都清空数据库
    mysql.clearcar()
    mysql.clearorder()
    mysql.clearsales()

    thread1 = threading.Thread(name='1', target=mysql.spider)
    thread2 = threading.Thread(name='2', target=mysql.sales)
    # thread3 = threading.Thread(name='2', target=a)

    thread1.start()
    thread2.start()
    # thread3.start()

    uvicorn.run(
        app='api:myapp',
        host='127.0.0.1',
        port=1223,
        reload=True,
        workers= 4
    )

    
