from fastapi import FastAPI
# from API.drug import my_druginfo
# from API.supl import my_supply
# from API.equip import my_equipment
# from API.area import my_equiparea
# from API.allnum import my_allnum
# from API.allprice import my_allprice
from fastapi.middleware.cors import CORSMiddleware
from car_data import my_car_data
import uvicorn

# 创建应用
myapp = FastAPI()
# 允许跨域
myapp.add_middleware(
    CORSMiddleware,
    allow_origins=['*'],
    allow_credentials=False,
    allow_methods=['*'],
    allow_headers=['*']
)


#加载子路由
myapp.include_router(
    router=my_car_data,
    prefix='/car',
    tags=['汽车子路由']
)
# myapp.include_router(
#     router=my_sales_data,
#     prefix='/sales',
#     tags=['员工子路由']
# )

# myapp.include_router(
#     router=my_orderr_data,
#     prefix='/orderr',
#     tags=['订单子路由']
# )
# # 加载子路由,相对于子路由
# myapp.include_router(
#     router=my_druginfo,
#     prefix='/enter_druginfo',
#     tags=['药品信息子路由']
# )

# myapp.include_router(
#     router=my_equipment,
#     prefix='/enter_equipment',
#     tags=['设备信息子路由']
# )
# myapp.include_router(
#     router=my_supply,
#     prefix='/enter_supply',
#     tags=['供应商子路由']
# )
# myapp.include_router(
#     router=my_equiparea,
#     prefix='/enter_equiparea',
#     tags=['设备供应商区域']
# )
# myapp.include_router(
#     router=my_allnum,
#     prefix='/enter_allnum',
#     tags=['采购总量']
# )
# myapp.include_router(
#     router=my_allprice,
#     prefix='/enter_allprice',
#     tags=['采购总金额']
# )
# 注册应用（post\put\get\delete,分别对应数据的CRUD）

@myapp.get(
    path='/',
    tags=["服务器首页"]
)
# 定义函数来提供上述注册服务
def welcome():
    return {
        'message': 'welcome!'
    }

if __name__ == '__main__':
    uvicorn.run(
        app='apimain:myapp',
        host='127.0.0.1',  # 默认为127.0.0.1,对外开放服务写0.0.0.0
        port=5800,  # 端口号
        reload=True,  # 热更新，修改代码后服务器自动重新加载
        workers=4  # 启用多线程，一般填写服务器CPU物理内核数
    )