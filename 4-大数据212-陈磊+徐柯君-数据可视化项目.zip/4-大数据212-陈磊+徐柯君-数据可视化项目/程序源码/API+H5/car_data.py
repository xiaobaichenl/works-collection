from fastapi import APIRouter
import pymysql

my_car_data = APIRouter()
conn = pymysql.connect(host="localhost",port = 3306, user="root", password="Cl20031121", database="car")


_cur = None
_sql = None
_result = None


@my_car_data.get(
    path='/CAR_DATA',
    tags=['汽车数据']
)

async def get_all_carData():
    json_data = []
    try:
        _cur = conn.cursor()
        _sql = '''
            select * from car
        '''
        _cur.execute(_sql)
        conn.commit()

        #获取表格的字段名
        row_headers = [column_name[0] for column_name in _cur.description]
        #获取数据
        _result = _cur.fetchall()
        #将所有数据封装成JSON格式
        for row_data in _result:
            json_data.append(dict(zip(row_headers,row_data)))
    except conn.Error as e:
        print(e)
    finally:
        _cur.close()
        # conn.close()
        _cur = None
        # 返回结果
    return json_data
