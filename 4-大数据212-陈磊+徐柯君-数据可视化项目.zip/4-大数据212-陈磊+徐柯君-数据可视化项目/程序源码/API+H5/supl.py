# 把所有的类别的API进行封装
from fastapi import APIRouter
import pymysql

# 创建子路由
my_supply = APIRouter()

@my_supply.get(
    path='/',
    tags=['供应商信息API']
)
def welcome():
    return {
        'message': 'Welcome to Supply API!'
    }

# 从数据库中读取所有类别并以json格式返回给前端
conn = pymysql.connect(
    host="localhost",
    user="root",
    password="123456",
    database="hospital_supply"
)
_cur = None
_sql = None
_result = None


@my_supply.get(
    path='/supply',
    tags=['供应商信息API']
)
async def get_all_categories():
    json_data = []
    try:
        _cur = conn.cursor()
        _sql = '''
                select supplier,quality,region,praise from supply 
        '''
        _cur.execute(_sql)
        conn.commit()
        # 动态获取表头信息
        row_headers = [column_name[0] for column_name in _cur.description]
        # 获取数据
        _result = _cur.fetchall()
        # 将所有数据封装成json格式
        for row_data in _result:
            json_data.append(dict(zip(row_headers, row_data)))
    except conn.Error as e:
        print(e)
    finally:
        _cur.close()
        # conn.close()
        _cur = None
    return json_data

