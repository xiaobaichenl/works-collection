from selenium import webdriver
from scrapy import Selector
import time
import csv

# 打开网页
driver = webdriver.Chrome("/Users/stitch/Desktop/work/chromedriver_mac_arm64/chromedriver")
currentHandle = driver.current_window_handle
driver.implicitly_wait(5)

url = 'https://www.guazi.com/buy?search=%257B%2522minor%2522%253A%2522bmw%2522%257D'
driver.get(url)
# 获取页面资源
res_page = Selector(text=driver.page_source)
buxian = driver.find_element(by='xpath',value='//*[@id="pageWrapper"]/div[1]/div[3]/div[1]/div[2]/div[1]/div[2]/div[1]/div[1]/span[1]')
buxian.click()
#在page1点击
res_page = Selector(text=driver.page_source)
pagenumber_list = res_page.xpath('//*[@id="pageWrapper"]/div[1]/div[3]/div[3]/div/ul/li/text()').getall()
pagenumber = int(pagenumber_list[-1])
basexpath =' //*[@id="pageWrapper"]/div[1]/div[3]/div[2]/div[1]/div[{}]'
for i in range (pagenumber):
    res_page = Selector(text=driver.page_source)
    res_num = res_page.xpath('//*[@id="pageWrapper"]/div[1]/div[3]/div[2]/div[1]/div/text()').getall()
    car_num = len(res_num)

    for i in range(car_num):
        
        xpath = basexpath.format(i+1)
        next_xpath = driver.find_element(by='xpath',value=xpath)  
        next_xpath.click()  
        # new_page = Selector(text=driver.page_source)
        driver.switch_to.window(driver.window_handles[-1])
        time.sleep(2)
        # li_list=new_page.find_elements_by_xpath('//*[@id="jobList"]/div')
        # for div in li_list:
        #     job_name=div.find_element_by_xpath('./div[1]/div[1]/div[1]/div[1]/a')
        #     job_price=div.find_element_by_xpath('./div[2]/div[1]/div[1]/div[2]/span')
        #     job_company=div.find_element_by_xpath('./div[2]/div[1]/div[2]/div[1]/a')
        title = driver.find_element(by='xpath',value='//*[@id="pageWrapper"]/div[1]/div[3]/div[4]/div[2]/h1/text()')

        print(title)
         # 标题# //*[@id="pageWrapper"]/div[1]/div[3]/div[4]/div[2]/h1/text()
        # 能源形式# //*[@id="pageWrapper"]/div[1]/div[3]/div[5]/div/div/div/div[1]/div[2]/div[2]/div/li[1]/div/text()
        # 厂商指导价哦# //*[@id="pageWrapper"]/div[1]/div[3]/div[5]/div/div/div/div[1]/div[2]/div[1]/div/li[3]/div/text()
        # 上市时间  //*[@id="pageWrapper"]/div[1]/div[3]/div[5]/div/div/div/div[1]/div[2]/div[1]/div/li[4]/div
        # 发动机//*[@id="pageWrapper"]/div[1]/div[3]/div[5]/div/div/div/div[1]/div[2]/div[2]/div/li[2]/div
        # 变速箱//*[@id="pageWrapper"]/div[1]/div[3]/div[5]/div/div/div/div[1]/div[2]/div[2]/div/li[3]/div
        # 油耗//*[@id="pageWrapper"]/div[1]/div[3]/div[5]/div/div/div/div[1]/div[2]/div[2]/div/li[4]/div
        # 车身形式//*[@id="pageWrapper"]/div[1]/div[3]/div[5]/div/div/div/div[1]/div[2]/div[3]/div/li[1]/div
  
    next_page = driver.find_element(by='xpath',value='//*[@id="pageWrapper"]/div[1]/div[3]/div[3]/div/button[2]/i')
    next_page.click()


# res_page = Selector(text=driver.page_source)
# temp = []
# for i in range(5):
#     # 获取页面资源
#     res_page = Selector(text=driver.page_source)
#     code = res_page.xpath('//*[@id="table_wrapper-table"]/tbody/tr/td[2]/a/text()').getall()
#     name = res_page.xpath('//*[@id="table_wrapper-table"]/tbody/tr/td[3]/a/text()').getall()
#     for j in range(len(code)):
#         temp.append([code[j], name[j]])
#         j += 1
#     # 点击下一页
#     button = driver.find_element(by='xpath', value='//*[@id="main-table_paginate"]/a[2]')
#     button.click()
#     i += 1

# f = open('wealth.csv', 'w', encoding='utf-8')
# csv_writer = csv.writer(f)
# csv_writer.writerow(['code', 'name'])
# for item in temp:
#     csv_writer.writerow(item)
# f.close()