##实现分析
# 抓取瓜子二手车上的网站
# 页面网址: https://www.guazi.com/buy?search=%257B%2522minor%2522%253A%2522bmw%2522%257D
# 获取到网页详情地址: https://mapi.guazi.com/car-source/carList/pcList?versionId=0.0.0.0&sourceFrom=wap&deviceId=9bc39cf1-8941-4a04-a163-03d71bdf1641&osv=Windows+10&minor=&sourceType=&ec_buy_car_list_ab=&location_city=&district_id=&tag=-1&license_date=&auto_type=&driving_type=&gearbox=&road_haul=&air_displacement=&emission=&car_color=&guobie=&bright_spot_config=&seat=&fuel_type=&order=&priceRange=0,-1&tag_types=&diff_city=&intention_options=&initialPriceRange=&monthlyPriceRange=&transfer_num=&car_year=&carid_qigangshu=&carid_jinqixingshi=&cheliangjibie=&page=1&pageSize=20&city_filter=13&city=13&guazi_city=13&qpres=&platfromSource=wap
# 获取所有的数据: 目标网址->发送请求(请求方式,请求头,乱码)->解析网页(正则表达式,xpath,BeautifulSoup)->保存数据(txt,csv,excel)
import time
from scrapy import Selector
import requests as rq  # 网络请求库
import urllib.request
from bs4 import BeautifulSoup as bs
from selenium import webdriver
import csv
import re
import json
from lxml import etree
import ssl
ssl._create_default_https_context = ssl._create_unverified_context
# driver = webdriver.Chrome("/Users/stitch/Desktop/work/chromedriver_mac_arm64/chromedriver")
# url = 'https://www.guazi.com/buy?search=%257B%2522minor%2522%253A%2522bmw%2522%257D'
# driver.get(url)
debug = False
csv_menu = []
sleep_time = 5
for item in range (3):
    url='https://mapi.guazi.com/car-source/carList/pcList?versionId=0.0.0.0&sourceFrom=wap&deviceId=9bc39cf1-8941-4a04-a163-03d71bdf1641&osv=Windows+10&minor=&sourceType=&ec_buy_car_list_ab=&location_city=&district_id=&tag=-1&license_date=&auto_type=&driving_type=&gearbox=&road_haul=&air_displacement=&emission=&car_color=&guobie=&bright_spot_config=&seat=&fuel_type=&order=&priceRange=0,-1&tag_types=&diff_city=&intention_options=&initialPriceRange=&monthlyPriceRange=&transfer_num=&car_year=&carid_qigangshu=&carid_jinqixingshi=&cheliangjibie=&page={}&pageSize=20&city_filter=13&city=13&guazi_city=13&qpres={}&platfromSource=wap'
    times = str(int(time.time()))
    url = url.format(item,times)
    headers={
        'olient-timestamp':times,
        'user-agent':'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Mobile Safari/537.36',
        'cookie':'uuid=11b6b55a-78af-461c-a788-14aeb5c7358e; sessionid=0e031da3-3ef9-4daf-83ed-cbb897812d32; cainfo=%7B%22ca_s%22%3A%22self%22%2C%22ca_n%22%3A%22self%22%2C%22ca_medium%22%3A%22-%22%2C%22ca_term%22%3A%22-%22%2C%22ca_content%22%3A%22-%22%2C%22ca_campaign%22%3A%22-%22%2C%22ca_kw%22%3A%22-%22%2C%22ca_i%22%3A%22-%22%2C%22scode%22%3A%22-%22%2C%22guid%22%3A%2211b6b55a-78af-461c-a788-14aeb5c7358e%22%7D; user_city_id=-1; cityDomain=www; puuid=c3352e1c-70c6-4912-c279-f39c91e7f892; CHDSSO=154125odouzonkesnzppbmqnue583875; CHDSOURCE=12; CHD_USER_ID=168715412559000068; hidden_city_bubble=1'
    }
    res=rq.get(url).text

    json_dict=json.loads(res)
    # print(len(json_dict["data"]["postList"]))
    for i in range (20):
        # print(json_dict["data"]["postList"][i]["clue_id"])
        baseurl='https://www.guazi.com/Detail?clueId={}'
        baseurl=baseurl.format(json_dict["data"]["postList"][i]["clue_id"])

        # 标题# //*[@id="pageWrapper"]/div[1]/div[3]/div[4]/div[2]/h1/text()
        # 能源形式# //*[@id="pageWrapper"]/div[1]/div[3]/div[5]/div/div/div/div[1]/div[2]/div[2]/div/li[1]/div/text()
        # 厂商指导价哦# //*[@id="pageWrapper"]/div[1]/div[3]/div[5]/div/div/div/div[1]/div[2]/div[1]/div/li[3]/div/text()
        # 上市时间  //*[@id="pageWrapper"]/div[1]/div[3]/div[5]/div/div/div/div[1]/div[2]/div[1]/div/li[4]/div
        # 发动机//*[@id="pageWrapper"]/div[1]/div[3]/div[5]/div/div/div/div[1]/div[2]/div[2]/div/li[2]/div
        # 变速箱//*[@id="pageWrapper"]/div[1]/div[3]/div[5]/div/div/div/div[1]/div[2]/div[2]/div/li[3]/div
        # 油耗//*[@id="pageWrapper"]/div[1]/div[3]/div[5]/div/div/div/div[1]/div[2]/div[2]/div/li[4]/div
        # 车身形式//*[@id="pageWrapper"]/div[1]/div[3]/div[5]/div/div/div/div[1]/div[2]/div[3]/div/li[1]/div
        header = {
            'user-agent':'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Mobile Safari/537.36'
        }
        # request =  urllib.request.Request(url=baseurl,headers=header)
        html = rq.get(baseurl,headers=header)
        text = html.text
        # sel = Selector(text=response)
        # content = response.read().decode('utf-8')
        # # 解析服务器响应的文件
        parse_html = etree.HTML(text)
        title = parse_html.xpath('//*[@id="pageWrapper"]/div[1]/div[3]/div[4]/div[2]/h1')
pass
        # print(title)