// setInterval( 

function gettitle() {
    // var baseURL = 'http://127.0.0.1:1222';
    $.ajax({
        url: "http://127.0.0.1:1223/orderr/ORDERR_DATA",
        type: "get",
        async: true,
        cache: false,
        dataType: "json",
        
        // beforeSend: function () {
        //     $("#ProductMsg").empty();
        // },
        success: function (json_data) {
            // console.log(json_data)
            if (json_data) {
                var l=[]
                // var l_saledata=[]
                // var l_price=[]

                
                for (i of json_data){
                    // console.log(i)
                    // for (item in i){
                var parts = i["title"].split(" ");        
                l.push(parts[0])
    
                }
                // console.log(l)
                var count = {};
                var result = [];
                for (var i = 0; i < l.length; i++) {
                  var element = l[i];
                  if (count[element]) {
                    count[element] += 1;
                  } else {
                    count[element] = 1;
                  }
                }
                // c.push(count)
                // console.log(c);
                var myChart = echarts.init(document.getElementById('main1'));
                for (var key in  count) {
                    if (count.hasOwnProperty(key)) {
                      var item = { "name": key, "value":  count[key] };
                      result.push(item);
                    }
                  }
                // console.log(result);

            var bgPatternImg = new Image();
            bgPatternImg.src = '/Users/stitch/Desktop/VsCodeP/项目化2/20/images/left-top3.jpg';
                
                    
            var option = {
                backgroundColor: { //背景
                    image: bgPatternImg,
                    repeat: 'repeat'
                }, 
                series: [{
                    type: 'wordCloud',
                   //maskImage: maskImage,
                    sizeRange: [15, 80],
                    rotationRange: [0, 0],
                    rotationStep: 45,
                    gridSize: 8,
                    shape: 'pentagon',
                    width: '100%',
                    height: '100%',
                     textStyle: {
                        normal: {
                            color: function () {
                                return 'rgb(' + [
                                    Math.round(Math.random() * 160),
                                    Math.round(Math.random() * 160),
                                    Math.round(Math.random() * 160)
                                ].join(',') + ')';
                            },
                            fontFamily: 'sans-serif',
                            fontWeight: 'normal'
                        },
                        emphasis: {
                            shadowBlur: 10,
                            shadowColor: '#333'
                        }
                    },
                    data: result
                }]
            };
            // 使用刚指定的配置项和数据显示图表。
            myChart.setOption(option);
            window.addEventListener("resize", function() {
                myChart.resize();
            });

                }//return l;
            }
        }
    );
}
// ,1000);