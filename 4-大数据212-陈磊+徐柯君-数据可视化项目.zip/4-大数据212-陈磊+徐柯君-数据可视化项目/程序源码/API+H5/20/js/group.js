function getgroup() {
    // var baseURL = 'http://127.0.0.1:1222';
    $.ajax({
        url: "http://127.0.0.1:1223/orderr/ORDERR_DATA",
        type: "get",
        async: true,
        cache: false,
        dataType: "json",
        
        // beforeSend: function () {
        //     $("#ProductMsg").empty();
        // },
        success: function (json_data) {
            // console.log(json_data)
            if (json_data) {
                var month = ""
                var t1=[]
                var t2=[]
                var t3=[]

                var team_11 = 0,team_12 = 0,team_13 = 0,team_14 = 0,team_15 = 0,team_16 = 0
                var team_21 = 0,team_22 = 0,team_23 = 0,team_24 = 0,team_25 = 0,team_26 = 0
                var team_31 = 0,team_32 = 0,team_33 = 0,team_34 = 0,team_35 = 0,team_36 = 0
               for (i of json_data){
                    month = i["saledata"].substr(5,2)
                    if((i["true_price"])== "-")
                    {
                        i["true_price"]="0"
                    }
                    // console.log(month)
                    // console.log(t1)
                    if(month=="01")
                    {
                        // console.log('aaa')
                        // console.log(Number(i["salesid"]))
                        if(Number(i["salesid"])<=6)
                        {
                            team_11+=Number(i["true_price"])
                        }
                        else if(Number(i["salesid"])>6 && Number(i["salesid"])<=12)
                        {
                            team_21+=Number(i["true_price"])
                        }
                        else
                        {
                            team_31+=Number(i["true_price"])
                        }
                    }
                    if(month=="02")
                    {
                        if( Number(i["salesid"])<=6)
                        {
                            team_12+=Number(i["true_price"])
                        }
                        else if(Number(i["salesid"])>6 && Number(i["salesid"])<=12)
                        {
                            team_22+=Number(i["true_price"])
                        }
                        else
                        {
                            team_32+=Number(i["true_price"])
                            // console.log(team_32)
                        }
                    }
                    if(month=="03")
                    {
                        if( Number(i["salesid"])<=6)
                        {
                            team_13+=Number(i["true_price"])
                        }
                        else if(Number(i["salesid"])>6 && Number(i["salesid"])<=12)
                        {
                            team_23+=Number(i["true_price"])
                        }
                        else
                        {
                            team_33+=Number(i["true_price"])
                        }
                    }
                    if(month=="04")
                    {
                        if( Number(i["salesid"])<=6)
                        {
                            team_14+=Number(i["true_price"])
                        }
                        else if(Number(i["salesid"])>6 && Number(i["salesid"])<=12)
                        {
                            team_24+=Number(i["true_price"])
                        }
                        else
                        {
                            team_34+=Number(i["true_price"])
                        }
                    }
                    if(month=="05")
                    {
                        if( Number(i["salesid"])<=6)
                        {
                            team_15+=Number(i["true_price"])
                        }
                        else if(Number(i["salesid"])>6 && Number(i["salesid"])<=12)
                        {
                            team_25+=Number(i["true_price"])
                        }
                        else
                        {
                            team_35+=Number(i["true_price"])
                        }
                    }
                    if(month=="06")
                    {
                        if( Number(i["salesid"])<=6)
                        {
                            team_16+=Number(i["true_price"])
                        }
                        else if(Number(i["salesid"])>6 && Number(i["salesid"])<=12)
                        {
                            team_26+=Number(i["true_price"])
                        }
                        else if(Number(i["salesid"])>=13)
                        {
                            team_36+=Number(i["true_price"])
                        }
                    }
                }
                t1.push(team_11)
                t1.push(team_12)
                t1.push(team_13)
                t1.push(team_14)
                t1.push(team_15)
                t1.push(team_16)
                
                t2.push(team_21)
                t2.push(team_22)
                t2.push(team_23)
                t2.push(team_24)
                t2.push(team_25)
                t2.push(team_26)

                t3.push(team_31)
                t3.push(team_32)
                t3.push(team_33)
                t3.push(team_34)
                t3.push(team_35)
                t3.push(team_36)
                // console.log(t3)
                // console.log(t2)
                // console.log(t1)
                var myChart3 = echarts.init(document.getElementById('main2'));
                myChart3.setOption({
                 
                        title : {
                            // text: '小组业绩',
        
                        },
                        tooltip : {
                            trigger: 'axis'
                        },
                        legend: {
                            data:['小组1','小组2','小组3']
                        },
                        toolbox: {
                            show : true,
                            feature : {
                                mark : {show: true},
                                dataView : {show: true, readOnly: false},
                                // magicType : {show: true, type: ['line', 'bar']},
                                // restore : {show: true},
                                saveAsImage : {show: true}
                            }
                        },
                        calculable : true,
                        xAxis : [
                            {
                                type : 'category',
                                boundaryGap : false,
                                data : ['一月','二月','三月','四月','五月','六月']
                            }
                        ],
                        yAxis : [
                            {
                                type : 'value',
                                axisLabel : {
                                    formatter: '{value} '
                                }
                            }
                        ],
                          grid: {                                 //图表距离边框的距离
          left: '5%',
          right: '5%',
          bottom: '0',
          top: '20%',
          containLabel: true
        },
                        series : [
                            {
                                name:'小组1',
                                type:'line',
                                data:t1,
                                markPoint : {
                                    data : [
                                        {type : 'max', name: '最大值'},
                                        {type : 'min', name: '最小值'}
                                    ]
                                },
                                markLine : {
                                    data : [
                                        {type : 'average', name: '平均值'}
                                    ]
                                }
                            },
                            {
                                name:'小组2',
                                type:'line',
                                data:t2,
                                markPoint : {
                                    data : [
                                        {name : '月最低', value : -2, xAxis: 1, yAxis: -1.5}
                                    ]
                                },
                                markLine : {
                                    data : [
                                        {type : 'average', name : '平均值'}
                                    ]
                                }
                            },
                            {
                                name:'小组3',
                                type:'line',
                                data:t3,
                                markPoint : {
                                    data : [
                                        {name : '月最低', value : -2, xAxis: 1, yAxis: -1.5}
                                    ]
                                },
                                markLine : {
                                    data : [
                                        {type : 'average', name : '平均值'}
                                    ]
                                }
                            }
                        ]
                    

                })








                }
            }
        }
    );
}
