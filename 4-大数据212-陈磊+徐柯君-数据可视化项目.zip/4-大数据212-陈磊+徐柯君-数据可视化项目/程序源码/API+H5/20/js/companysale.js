function getcompanysale() {
    
    // var baseURL = 'http://127.0.0.1:1222';
    $.ajax({
        url: "http://127.0.0.1:1223/orderr/ORDERR_DATA",
        type: "get",
        async: true,
        cache: false,
        dataType: "json",
        
        // beforeSend: function () {
        //     $("#ProductMsg").empty();
        // },
        success: function (json_data) {
            // console.log(json_data)
            if (json_data) {
                var l_title=[]
                var l_saledata=[]
                var l_price=[]
                var price=[]
                var month = ""
                var month_1 = 0
                var month_2 = 0
                var month_3 = 0
                var month_4 = 0
                var month_5 = 0
                var month_6 = 0
                for (i of json_data){
                    // console.log(i)
                    for (item in i){
                    // console.log('aaa')
                    // console.log(item)
                    // console.log(i[item])
                    
                    if (item == "title")
                    {
                        l_title.push(i[item])
                    }
                    if (item == "saledata")
                    {
                        month = i[item].substr(5,2)
                        if((i["true_price"])== "-")
                        {
                            i["true_price"]="0"
                        }
                        if(month=="01")
                        {
                            month_1+=Number(i["true_price"])
                        }
                        if(month=="02")
                        {
                            month_2+=Number(i["true_price"])
                        }
                        // console.log(month_2)
                        if(month=="03")
                        {
                            month_3+=Number(i["true_price"])
                        }

                        if(month=="04")
                        {
                            month_4+=Number(i["true_price"])
                        }
                        if(month=="05")
                        {
                            month_5+=Number(i["true_price"])
                        }
                        if(month=="06")
                        {
                            month_6+=Number(i["true_price"])
                        }
                        // console.log(month_6)
                        // console.log(i["true_price"])
                        // l_saledata.push(i[item])
                    }  
                    // if (item == "true_price")
                    // {
                    //     l_price.push(i[item])
                    // }  
                    }
                }
                price.push(month_1)
                price.push(month_2)
                price.push(month_3)
                price.push(month_4)
                price.push(month_5)
                price.push(month_6)
                // console.log(price)
                var myChart2 = echarts.init(document.getElementById('main5'));
                myChart2.setOption({
                    title : {
                        text: '公司上半年销售额',
                        // subtext: '纯属虚构'
                    },
                    tooltip : {
                        trigger: 'axis'
                    },
                    legend: {
                        data:['销售额']
                    },
                    toolbox: {
                        show : true,
                        feature : {
                            mark : {show: true},
                            dataView : {show: true, readOnly: false},
                            magicType : {show: true, type: ['line', 'bar']},
                            restore : {show: true},
                            saveAsImage : {show: true}
                        }
                    },
                    calculable : true,
                    xAxis : [
                        {
                            type : 'category',
                            data : ['1月','2月','3月','4月','5月','6月']
                        }
                    ],
                    yAxis : [
                        {
                            type : 'value'
                        }
                    ],
                    series : [
                        {
                            name:'销售额',
                            type:'bar',
                            data:price,
                            markPoint : {
                                data : [
                                    {type : 'max', name: '最大值'},
                                    {type : 'min', name: '最小值'}
                                ]
                            },
                            markLine : {
                                data : [
                                    {type : 'average', name: '平均值'}
                                ]
                            }
                        },
                        
                        
                    ]
                   
                             
                })

        
                    // console.log(value,'点击的每块元素');
                    
                             
                // })

                }
            }
        }
    );
 
}
