
function getperson() {
    // var baseURL = 'http://127.0.0.1:1222';
    $.ajax({
        url: "http://127.0.0.1:1223/orderr/ORDERR_DATA",
        type: "get",
        async: true,
        cache: false,
        dataType: "json",
        
        // beforeSend: function () {
        //     $("#ProductMsg").empty();
        // },
        success: function (json_data) {
            // console.log(json_data)
            if (json_data) {
                var month = ""
                var p0=[],p1=[],p2=[],p3=[],p4=[],p5=[]
                var p6=[],p7=[],p8=[],p9=[],p10=[],p11=[]
                var p12=[],p13=[],p14=[],p15=[],p16=[],p17=[],p18=[]
                var per_01 = 0,per_02 = 0,per_03 = 0,per_04 = 0,per_05 = 0,per_06 = 0
                var per_11 = 0,per_12 = 0,per_13 = 0,per_14 = 0,per_15 = 0,per_16 = 0
                var per_21 = 0,per_22 = 0,per_23 = 0,per_24 = 0,per_25 = 0,per_26 = 0
                var per_31 = 0,per_32 = 0,per_33 = 0,per_34 = 0,per_35 = 0,per_36 = 0
                var per_41 = 0,per_42 = 0,per_43 = 0,per_44 = 0,per_45 = 0,per_46 = 0
                var per_51 = 0,per_52 = 0,per_53 = 0,per_54 = 0,per_55 = 0,per_56 = 0
                var per_61 = 0,per_62 = 0,per_63 = 0,per_64 = 0,per_65 = 0,per_66 = 0
                var per_71 = 0,per_72 = 0,per_73 = 0,per_74 = 0,per_75 = 0,per_76 = 0
                var per_81 = 0,per_82 = 0,per_83 = 0,per_84 = 0,per_85 = 0,per_86 = 0
                var per_91 = 0,per_92 = 0,per_93 = 0,per_94 = 0,per_95 = 0,per_96 = 0
                var per_101 = 0,per_102 = 0,per_103 = 0,per_104 = 0,per_105 = 0,per_106 = 0
                var per_111 = 0,per_112 = 0,per_113 = 0,per_114 = 0,per_115 = 0,per_116 = 0
                var per_121 = 0,per_122 = 0,per_123 = 0,per_124 = 0,per_125 = 0,per_126 = 0
                var per_131 = 0,per_132 = 0,per_133 = 0,per_134 = 0,per_135 = 0,per_136 = 0
                var per_141 = 0,per_142 = 0,per_143 = 0,per_144 = 0,per_145 = 0,per_146 = 0
                var per_151 = 0,per_152 = 0,per_153 = 0,per_154 = 0,per_155 = 0,per_156 = 0
                var per_161 = 0,per_162 = 0,per_163 = 0,per_164 = 0,per_165 = 0,per_166 = 0
                var per_171 = 0,per_172 = 0,per_173 = 0,per_174 = 0,per_175 = 0,per_176 = 0
                var per_181 = 0,per_182 = 0,per_183 = 0,per_184 = 0,per_185 = 0,per_186 = 0
               
                for (i of json_data){
                    month = i["saledata"].substr(5,2)
                    // console.log(month)
                    // console.log(p1)
                    if(month=="01")
                    {
                        // console.log('aaa')
                        // console.log(Number(i["salesid"]))
                        if(Number(i["salesid"])==0)
                        {
                            per_01+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==1)
                        {
                            per_11+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==2)
                        {
                            per_21+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==3)
                        {
                            per_31+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==4)
                        {
                            per_41+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==5)
                        {
                            per_51+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==6)
                        {
                            per_61+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==7)
                        {
                            per_71+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==8)
                        {
                            per_81+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==9)
                        {
                            per_91+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==10)
                        {
                            per_101+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==11)
                        {
                            per_111+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==12)
                        {
                            per_121+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==13)
                        {
                            per_131+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==14)
                        {
                            per_141+=Number(i["true_price"])
                        }if(Number(i["salesid"])==15)
                        {
                            per_151+=Number(i["true_price"])
                        }if(Number(i["salesid"])==16)
                        {
                            per_161+=Number(i["true_price"])
                        }if(Number(i["salesid"])==17)
                        {
                            per_171+=Number(i["true_price"])
                        }if(Number(i["salesid"])==18)
                        {
                            per_181+=Number(i["true_price"])
                        }
                    }
                    if(month=="02")
                    {
                        if(Number(i["salesid"])==0)
                        {
                            per_02+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==1)
                        {
                            per_12+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==2)
                        {
                            per_22+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==3)
                        {
                            per_32+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==4)
                        {
                            per_42+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==5)
                        {
                            per_52+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==6)
                        {
                            per_62+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==7)
                        {
                            per_72+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==8)
                        {
                            per_82+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==9)
                        {
                            per_92+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==10)
                        {
                            per_102+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==11)
                        {
                            per_112+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==12)
                        {
                            per_122+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==13)
                        {
                            per_132+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==14)
                        {
                            per_142+=Number(i["true_price"])
                        }if(Number(i["salesid"])==15)
                        {
                            per_152+=Number(i["true_price"])
                        }if(Number(i["salesid"])==16)
                        {
                            per_162+=Number(i["true_price"])
                        }if(Number(i["salesid"])==17)
                        {
                            per_172+=Number(i["true_price"])
                        }if(Number(i["salesid"])==18)
                        {
                            per_182+=Number(i["true_price"])
                        }
                    }
                    if(month=="03")
                    {
                        if(Number(i["salesid"])==0)
                        {
                            per_03+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==1)
                        {
                            per_13+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==2)
                        {
                            per_23+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==3)
                        {
                            per_33+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==4)
                        {
                            per_43+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==5)
                        {
                            per_53+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==6)
                        {
                            per_63+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==7)
                        {
                            per_73+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==8)
                        {
                            per_83+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==9)
                        {
                            per_93+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==10)
                        {
                            per_103+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==11)
                        {
                            per_113+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==12)
                        {
                            per_123+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==13)
                        {
                            per_133+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==14)
                        {
                            per_143+=Number(i["true_price"])
                        }if(Number(i["salesid"])==15)
                        {
                            per_153+=Number(i["true_price"])
                        }if(Number(i["salesid"])==16)
                        {
                            per_163+=Number(i["true_price"])
                        }if(Number(i["salesid"])==17)
                        {
                            per_173+=Number(i["true_price"])
                        }if(Number(i["salesid"])==18)
                        {
                            per_183+=Number(i["true_price"])
                        }
                    }
                    if(month=="04")
                    {
                        if(Number(i["salesid"])==0)
                        {
                            per_04+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==1)
                        {
                            per_14+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==2)
                        {
                            per_24+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==3)
                        {
                            per_34+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==4)
                        {
                            per_44+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==5)
                        {
                            per_54+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==6)
                        {
                            per_64+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==7)
                        {
                            per_74+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==8)
                        {
                            per_84+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==9)
                        {
                            per_94+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==10)
                        {
                            per_104+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==11)
                        {
                            per_114+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==12)
                        {
                            per_124+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==13)
                        {
                            per_134+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==14)
                        {
                            per_144+=Number(i["true_price"])
                        }if(Number(i["salesid"])==15)
                        {
                            per_154+=Number(i["true_price"])
                        }if(Number(i["salesid"])==16)
                        {
                            per_164+=Number(i["true_price"])
                        }if(Number(i["salesid"])==17)
                        {
                            per_174+=Number(i["true_price"])
                        }if(Number(i["salesid"])==18)
                        {
                            per_184+=Number(i["true_price"])
                        }
                    }
                    if(month=="05")
                    {
                        if(Number(i["salesid"])==0)
                        {
                            per_05+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==1)
                        {
                            per_15+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==2)
                        {
                            per_25+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==3)
                        {
                            per_35+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==4)
                        {
                            per_45+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==5)
                        {
                            per_55+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==6)
                        {
                            per_65+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==7)
                        {
                            per_75+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==8)
                        {
                            per_85+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==9)
                        {
                            per_95+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==10)
                        {
                            per_105+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==11)
                        {
                            per_115+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==12)
                        {
                            per_125+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==13)
                        {
                            per_135+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==14)
                        {
                            per_145+=Number(i["true_price"])
                        }if(Number(i["salesid"])==15)
                        {
                            per_155+=Number(i["true_price"])
                        }if(Number(i["salesid"])==16)
                        {
                            per_165+=Number(i["true_price"])
                        }if(Number(i["salesid"])==17)
                        {
                            per_175+=Number(i["true_price"])
                        }if(Number(i["salesid"])==18)
                        {
                            per_185+=Number(i["true_price"])
                        }
                    }
                    if(month=="06")
                    {
                        if(Number(i["salesid"])==0)
                        {
                            per_06+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==1)
                        {
                            per_16+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==2)
                        {
                            per_26+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==3)
                        {
                            per_36+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==4)
                        {
                            per_46+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==5)
                        {
                            per_56+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==6)
                        {
                            per_66+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==7)
                        {
                            per_76+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==8)
                        {
                            per_86+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==9)
                        {
                            per_96+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==10)
                        {
                            per_106+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==11)
                        {
                            per_116+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==12)
                        {
                            per_126+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==13)
                        {
                            per_136+=Number(i["true_price"])
                        }
                        if(Number(i["salesid"])==14)
                        {
                            per_146+=Number(i["true_price"])
                        }if(Number(i["salesid"])==15)
                        {
                            per_156+=Number(i["true_price"])
                        }if(Number(i["salesid"])==16)
                        {
                            per_166+=Number(i["true_price"])
                        }if(Number(i["salesid"])==17)
                        {
                            per_176+=Number(i["true_price"])
                        }if(Number(i["salesid"])==18)
                        {
                            per_186+=Number(i["true_price"])
                        }
                    }
                }
                p0.push(per_11)
                p0.push(per_12)
                p0.push(per_13)
                p0.push(per_14)
                p0.push(per_15)
                p0.push(per_16)

                p1.push(per_11)
                p1.push(per_12)
                p1.push(per_13)
                p1.push(per_14)
                p1.push(per_15)
                p1.push(per_16)
              
                
                p2.push(per_21)
                p2.push(per_22)
                p2.push(per_23)
                p2.push(per_24)
                p2.push(per_25)
                p2.push(per_26)

                p3.push(per_31)
                p3.push(per_32)
                p3.push(per_33)
                p3.push(per_34)
                p3.push(per_35)
                p3.push(per_36)

                p4.push(per_41)
                p4.push(per_42)
                p4.push(per_43)
                p4.push(per_44)
                p4.push(per_45)
                p4.push(per_46)

                p5.push(per_51)
                p5.push(per_52)
                p5.push(per_53)
                p5.push(per_54)
                p5.push(per_55)
                p5.push(per_56)
                
                p6.push(per_61)
                p6.push(per_62)
                p6.push(per_63)
                p6.push(per_64)
                p6.push(per_65)
                p6.push(per_66)

                p7.push(per_71)
                p7.push(per_72)
                p7.push(per_73)
                p7.push(per_74)
                p7.push(per_75)
                p7.push(per_76)

                p8.push(per_81)
                p8.push(per_82)
                p8.push(per_83)
                p8.push(per_84)
                p8.push(per_85)
                p8.push(per_86)
                
                p9.push(per_91)
                p9.push(per_92)
                p9.push(per_93)
                p9.push(per_94)
                p9.push(per_95)
                p9.push(per_96)

                p10.push(per_101)
                p10.push(per_102)
                p10.push(per_103)
                p10.push(per_104)
                p10.push(per_105)
                p10.push(per_106)

                p11.push(per_111)
                p11.push(per_112)
                p11.push(per_113)
                p11.push(per_114)
                p11.push(per_115)
                p11.push(per_116)

                p12.push(per_121)
                p12.push(per_122)
                p12.push(per_123)
                p12.push(per_124)
                p12.push(per_125)
                p12.push(per_126)

                p13.push(per_131)
                p13.push(per_132)
                p13.push(per_133)
                p13.push(per_134)
                p13.push(per_135)
                p13.push(per_136)

                p14.push(per_141)
                p14.push(per_142)
                p14.push(per_143)
                p14.push(per_144)
                p14.push(per_145)
                p14.push(per_146)

                p15.push(per_151)
                p15.push(per_152)
                p15.push(per_153)
                p15.push(per_154)
                p15.push(per_155)
                p15.push(per_156)

                p16.push(per_161)
                p16.push(per_162)
                p16.push(per_163)
                p16.push(per_164)
                p16.push(per_165)
                p16.push(per_166)

                p17.push(per_171)
                p17.push(per_172)
                p17.push(per_173)
                p17.push(per_174)
                p17.push(per_175)
                p17.push(per_176)
                
                p18.push(per_181)
                p18.push(per_182)
                p18.push(per_183)
                p18.push(per_184)
                p18.push(per_185)
                p18.push(per_186)
                // console.log(p3)
                // console.log(p2)
                // console.log(p1)
                
                    

                








                }
            }
        }
    );
}
