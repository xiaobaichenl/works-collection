function getform() {
    // var baseURL = 'http://127.0.0.1:1222';
    $.ajax({
        url: "http://127.0.0.1:1223/orderr/ORDERR_DATA",
        type: "get",
        async: true,
        cache: false,
        dataType: "json",
        
        // beforeSend: function () {
        //     $("#ProductMsg").empty();
        // },
        success: function (json_data) {
          // console.log(json_data)
          if (json_data) {
     
              var xcx = 0
              var std = 0
              var wz = 0
              let listdata = JSON.parse(JSON.stringify(json_data))
              for (i of json_data){
                  // console.log(i)
                  for (item in i){
                  // console.log('aaa')
                  // console.log(item)
                  // console.log(i[item])
                  if (i[item] == "小程序")
                  {
                      xcx += 1
                  }
                  if (i[item] == "实体店")
                  {
                      std += 1
                  }  
                  if (i[item] == "网站")
                  {
                      wz += 1
                  }  
                  }
              }
              // console.log(json_data[0],'**************')
              // console.log(xcx)

              // console.log(cwb)
              // console.log(kjb)
              // alert(cwb)
              // l.append()
              // res_key = list(json_data.keys())
              // res_value= list(json_data.values())
              var myChart = echarts.init(document.getElementById('main10'));
              myChart.setOption({
                tooltip: {
                  trigger: 'item'
                },
                legend: {
                  top: '5%',
                  left: 'center'
                },
                series: [
                  {
                    name: 'Access From',
                    type: 'pie',
                    radius: ['40%', '70%'],
                    avoidLabelOverlap: false,
                    itemStyle: {
                      borderRadius: 10,
                      borderColor: '#fff',
                      borderWidth: 2
                    },
                    label: {
                      show: false,
                      position: 'center'
                    },
                    emphasis: {
                      label: {
                        show: true,
                        fontSize: 40,
                        fontWeight: 'bold'
                      }
                    },
                    labelLine: {
                      show: false
                    },
                    data: [
                      { value:xcx, name: '小程序' },
                      { value:std, name: '实体店' },
                      { value:wz, name: '网站' },
                     
                    ]
                  }
                ]
            })
           

            }
        }
    }
    

);
}