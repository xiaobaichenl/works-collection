// setInterval( 

function getorder() {
    // var baseURL = 'http://127.0.0.1:1222';
    $.ajax({
        url: "http://127.0.0.1:1223/orderr/ORDERR_DATA",
        type: "get",
        async: true,
        cache: false,
        dataType: "json",
        
        // beforeSend: function () {
        //     $("#ProductMsg").empty();
        // },
        success: function (json_data) {
            // console.log(json_data)
            if (json_data) {
                var l=[]
                // var l_saledata=[]
                // var l_price=[]
                var xxb = 0
                var cwb = 0
                var kjb = 0
               
                for (i of json_data){
                    // console.log(i)
                    // for (item in i){
                        
                        var list=[]
                        list.push(i["title"])
                        list.push(i["saledata"])
                        list.push(i["true_price"])
                        l.push(list)
                    // console.log(i.cusscore,'3222')
                    $("#deantalk .maquee ul").append(`<li>
					<div>${i["title"]}</div>
                    <div>${i["saledata"]}</div>
                    <div>${i["true_price"]}</div>
				</div>`)
    
                }
                // console.log(l)
              

                }return l;
            }
        }
    );
}
// ,1000);