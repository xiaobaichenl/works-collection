function getpro() {
    // var baseURL = 'http://127.0.0.1:1222';
    $.ajax({
        url: "http://127.0.0.1:1223/orderr/ORDERR_DATA",
        type: "get",
        async: true,
        cache: false,
        dataType: "json",
        
        // beforeSend: function () {
        //     $("#ProductMsg").empty();
        // },
       

    success: function (json_data) {
    // console.log(json_data)
    if (json_data) {
        

        var xcx = 0
        var std = 0
        var wz = 0
        for (item in i){
            if(i["saleform"]=='小程序')
                xcx+=1
            if(i["saleform"]=='实体店')
                std+=1
            if(i["saleform"]=='网站')
                wz+=1
        }
        // let listdata = JSON.parse(JSON.stringify(json_data))
        var saleproCounts = {};
        for (var i = 0; i < json_data.length; i++){
            // console.log(i)
            // console.log(i["salepro"])
            var salepro = json_data[i].salepro;
            // 如果该salepro在saleproCounts中不存在，则初始化为1；如果存在，则加1
            if (!saleproCounts[salepro]) {
                saleproCounts[salepro] = 1;
            } else {
                saleproCounts[salepro]++;
            }
        var transformedData = [];

        // 遍历原始数据对象
        for (var key in saleproCounts) {
            // 创建新的对象，并设置value和name属性
            var transformedObj = {
                value: saleproCounts[key],
                name: key
            };
        
            // 将新对象添加到转换后的数组中
            transformedData.push(transformedObj);
        }
        console.log(transformedData);

        var myChart = echarts.init(document.getElementById('main3'));
        myChart.setOption({

              tooltip: {
                trigger: 'item'
              },
              legend: {
                orient: 'vertical',
                left: 'left'
              },
              series: [
                {
                  name: '省份',
                  type: 'pie',
                  radius: '50%',
                  data: transformedData,
                  emphasis: {
                    itemStyle: {
                      shadowBlur: 10,
                      shadowOffsetX: 0,
                    //   shadowColor: 'rgba(0, 0, 0, 0.5)'
                    }
                  }
                }
              ]
           
                     
        })
        // myChart.on("click", function(item){
        //     let rightlist = listdata.filter(list => list.salesdepartment==item.name)
        //     //  console.log(item,'点击的每块元素',rightlist);
        //     /*if(data[name] === "销售部"){
                
        //     } else {
        //         // img.style.display = "block";
        //         // btn.innerHTML = "隐藏";
        //         // // isShow = true;
        //     }*/

        //     // console.log(value,'点击的每块元素');
        //     // $('.main3_List .maquee').children().remove()
        //     // for(let i=0; i< rightlist.length;i++) {
        //     //     // console.log(rightlist[i].salesid,'888')
               
        //     //     $(".main3_List .maquee").append(`<div class="li_box">
        //     //             <div>${rightlist[i].salesid}</div>
        //     //             <div>${rightlist[i].salesname}</div>
        //     //             <div>${rightlist[i].salesdepartment}</div>
        //     //             <div>${rightlist[i].salesteam}</div>
        //     //      </div>`)
        //     // }
           
        //   })
        }
    }
}
}
);
}