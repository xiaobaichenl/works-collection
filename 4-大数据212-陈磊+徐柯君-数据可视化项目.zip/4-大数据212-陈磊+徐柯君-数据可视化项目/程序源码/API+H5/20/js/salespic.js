function getsales() {
    // var baseURL = 'http://127.0.0.1:1222';
    $.ajax({
        url: "http://127.0.0.1:1223/sales/SALES_DATA",
        type: "get",
        async: true,
        cache: false,
        dataType: "json",
        
        // beforeSend: function () {
        //     $("#ProductMsg").empty();
        // },
        success: function (json_data) {
            // console.log(json_data)
            if (json_data) {
       
                var xxb = 0
                var cwb = 0
                var kjb = 0
                let listdata = JSON.parse(JSON.stringify(json_data))
                for (i of json_data){
                    // console.log(i)
                    for (item in i){
                    // console.log('aaa')
                    // console.log(item)
                    // console.log(i[item])
                    if (i[item] == "销售部")
                    {
                        xxb += 1
                    }
                    if (i[item] == "财务部")
                    {
                        cwb += 1
                    }  
                    if (i[item] == "技术部")
                    {
                        kjb += 1
                    }  
                    }
                }
                // console.log(json_data[0],'**************')
                // console.log(xxb)
                // console.log(cwb)
                // console.log(kjb)
                // alert(cwb)
                // l.append()
                // res_key = list(json_data.keys())
                // res_value= list(json_data.values())
                var myChart = echarts.init(document.getElementById('main1'));
                myChart.setOption({
                    // title : {
                    //     text: '各部门职员分布',
                    //     x:'center'
                    // },
                    tooltip : {
                        trigger: 'item',
                        formatter: "{a} <br/>{b} : {c} ({d}%)"
                    },
                    legend: {
                        orient : 'vertical',
                        x : 'left',
                        data:['销售部','技术部','财务部']
                    },
                    toolbox: {
                        show : true,
                        feature : {
                            mark : {show: true},
                            dataView : {show: true, readOnly: false},
                            magicType : {
                                show: true, 
                                type: ['pie', 'funnel'],
                                option: {
                                    funnel: {
                                        x: '25%',
                                        width: '50%',
                                        funnelAlign: 'left',
                                        max: 1548
                                    }
                                }
                            },
                            restore : {show: true},
                            saveAsImage : {show: true}
                        }
                    },
                    calculable : true,
                    series : [
                        {
                            name:'分析点',
                            type:'pie',
                            radius : '55%',
                            center: ['50%', '60%'],
                            data: 
                            [
                                {value:0, name:'销量'},
                                {value:0, name:'销售地'},
                                {value:0, name:'销售渠道'},
                               
                            ]
                        }
                    ]
                   
                             
                })
                myChart.on("click", function(item){
                    let rightlist = listdata.filter(list => list.salesdepartment==item.name)
                    //  console.log(item,'点击的每块元素',rightlist);
                    /*if(data[name] === "销售部"){
                        
                    } else {
                        // img.style.display = "block";
                        // btn.innerHTML = "隐藏";
                        // // isShow = true;
                    }*/
        
                    // console.log(value,'点击的每块元素');
                    $('.main3_List .maquee').children().remove()
                    for(let i=0; i< rightlist.length;i++) {
                        // console.log(rightlist[i].salesid,'888')
                       
                        $(".main3_List .maquee").append(`<div class="li_box">
                                <div>${rightlist[i].salesid}</div>
                                <div>${rightlist[i].salesname}</div>
                                <div>${rightlist[i].salesdepartment}</div>
                                <div>${rightlist[i].salesteam}</div>
                         </div>`)
                    }
                   
                  })

                }
            }
        }
        
    
    );
}