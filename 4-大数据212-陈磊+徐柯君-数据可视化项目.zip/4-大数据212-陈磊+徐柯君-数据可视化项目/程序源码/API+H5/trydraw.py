import radar
# import requests
# import json
# r = requests.get('http://127.0.0.1:1222/sales/SALES_DATA')                                   # 最基本的不带参数的get请求
# print(r.json())

# xxb = 0
# cwb = 0
# kjb = 0
# for i in r.json():
#     print(i)
#     for item in i:
#         # print(i[item])
#         if i[item] == "销售部":
#             xxb += 1
#         if i[item] == "财务部":
#             cwb += 1
#         if i[item] == "技术部":
#             kjb += 1
# print(xxb,cwb,kjb)
l = []
saledata = str(radar.random_date("2023-01-01","2023-06-20"))
# l.append(saledata)
# print(l)
date = saledata.split(" ")
print(date)